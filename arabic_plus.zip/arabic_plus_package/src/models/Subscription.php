<?php
/**
 * نموذج الاشتراك
 * يتعامل مع عمليات الاشتراكات مثل إنشاء اشتراك جديد والتحقق من صلاحية الاشتراك
 */
class Subscription {
    private $db;
    
    /**
     * المُنشئ - يقوم بإنشاء اتصال بقاعدة البيانات
     */
    public function __construct() {
        $this->db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($this->db->connect_error) {
            die("فشل الاتصال بقاعدة البيانات: " . $this->db->connect_error);
        }
    }
    
    /**
     * إنشاء اشتراك جديد
     * 
     * @param int $userId معرف المستخدم
     * @param string $planType نوع الخطة (monthly, quarterly, yearly)
     * @param float $amount المبلغ
     * @param string $paymentMethod طريقة الدفع
     * @param string $transactionId معرف المعاملة (اختياري)
     * @return bool|int معرف الاشتراك الجديد أو false في حالة الفشل
     */
    public function createSubscription($userId, $planType, $amount, $paymentMethod, $transactionId = null) {
        // تحديد تاريخ البداية والنهاية
        $startDate = date('Y-m-d');
        $endDate = $this->calculateEndDate($startDate, $planType);
        
        // إعداد الاستعلام
        $stmt = $this->db->prepare("INSERT INTO subscriptions (user_id, plan_type, amount, payment_method, transaction_id, start_date, end_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'active')");
        $stmt->bind_param("isdsss", $userId, $planType, $amount, $paymentMethod, $transactionId, $startDate, $endDate);
        
        // تنفيذ الاستعلام
        if ($stmt->execute()) {
            $subscriptionId = $stmt->insert_id;
            $stmt->close();
            return $subscriptionId;
        } else {
            $stmt->close();
            return false;
        }
    }
    
    /**
     * حساب تاريخ انتهاء الاشتراك بناءً على نوع الخطة
     * 
     * @param string $startDate تاريخ البداية
     * @param string $planType نوع الخطة
     * @return string تاريخ الانتهاء
     */
    private function calculateEndDate($startDate, $planType) {
        $date = new DateTime($startDate);
        
        switch ($planType) {
            case 'monthly':
                $date->add(new DateInterval('P1M')); // إضافة شهر واحد
                break;
            case 'quarterly':
                $date->add(new DateInterval('P3M')); // إضافة ثلاثة أشهر
                break;
            case 'yearly':
                $date->add(new DateInterval('P1Y')); // إضافة سنة واحدة
                break;
            default:
                $date->add(new DateInterval('P1M')); // افتراضيًا شهر واحد
        }
        
        return $date->format('Y-m-d');
    }
    
    /**
     * التحقق من وجود اشتراك نشط للمستخدم
     * 
     * @param int $userId معرف المستخدم
     * @return bool هل يوجد اشتراك نشط أم لا
     */
    public function isActive($userId) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT id FROM subscriptions WHERE user_id = ? AND status = 'active' AND end_date >= CURDATE() ORDER BY end_date DESC LIMIT 1");
        $stmt->bind_param("i", $userId);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        $isActive = $result->num_rows > 0;
        $stmt->close();
        
        return $isActive;
    }
    
    /**
     * الحصول على تفاصيل الاشتراك النشط للمستخدم
     * 
     * @param int $userId معرف المستخدم
     * @return array|bool تفاصيل الاشتراك أو false إذا لم يكن هناك اشتراك نشط
     */
    public function getActiveSubscription($userId) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT * FROM subscriptions WHERE user_id = ? AND status = 'active' AND end_date >= CURDATE() ORDER BY end_date DESC LIMIT 1");
        $stmt->bind_param("i", $userId);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $subscription = $result->fetch_assoc();
            $stmt->close();
            return $subscription;
        }
        
        $stmt->close();
        return false;
    }
    
    /**
     * الحصول على تاريخ الاشتراك للمستخدم
     * 
     * @param int $userId معرف المستخدم
     * @return array تاريخ الاشتراكات
     */
    public function getUserSubscriptionHistory($userId) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT * FROM subscriptions WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->bind_param("i", $userId);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        $subscriptions = [];
        while ($row = $result->fetch_assoc()) {
            $subscriptions[] = $row;
        }
        
        $stmt->close();
        return $subscriptions;
    }
    
    /**
     * إلغاء اشتراك
     * 
     * @param int $subscriptionId معرف الاشتراك
     * @return bool نجاح أو فشل العملية
     */
    public function cancelSubscription($subscriptionId) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("UPDATE subscriptions SET status = 'cancelled' WHERE id = ?");
        $stmt->bind_param("i", $subscriptionId);
        
        // تنفيذ الاستعلام
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    }
    
    /**
     * تجديد اشتراك
     * 
     * @param int $subscriptionId معرف الاشتراك
     * @param float $amount المبلغ
     * @param string $paymentMethod طريقة الدفع
     * @param string $transactionId معرف المعاملة (اختياري)
     * @return bool|int معرف الاشتراك الجديد أو false في حالة الفشل
     */
    public function renewSubscription($subscriptionId, $amount, $paymentMethod, $transactionId = null) {
        // الحصول على تفاصيل الاشتراك الحالي
        $stmt = $this->db->prepare("SELECT user_id, plan_type, end_date FROM subscriptions WHERE id = ?");
        $stmt->bind_param("i", $subscriptionId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            $stmt->close();
            return false;
        }
        
        $subscription = $result->fetch_assoc();
        $stmt->close();
        
        // تحديد تاريخ البداية والنهاية
        $startDate = $subscription['end_date']; // تاريخ البداية هو تاريخ انتهاء الاشتراك الحالي
        $endDate = $this->calculateEndDate($startDate, $subscription['plan_type']);
        
        // إنشاء اشتراك جديد
        $stmt = $this->db->prepare("INSERT INTO subscriptions (user_id, plan_type, amount, payment_method, transaction_id, start_date, end_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'active')");
        $stmt->bind_param("isdsss", $subscription['user_id'], $subscription['plan_type'], $amount, $paymentMethod, $transactionId, $startDate, $endDate);
        
        // تنفيذ الاستعلام
        if ($stmt->execute()) {
            $newSubscriptionId = $stmt->insert_id;
            $stmt->close();
            return $newSubscriptionId;
        } else {
            $stmt->close();
            return false;
        }
    }
    
    /**
     * الحصول على جميع الاشتراكات
     * 
     * @param string $status حالة الاشتراك (اختياري)
     * @return array قائمة الاشتراكات
     */
    public function getAllSubscriptions($status = null) {
        // بناء الاستعلام
        $query = "SELECT s.*, u.username, u.email, u.full_name FROM subscriptions s JOIN users u ON s.user_id = u.id";
        
        if ($status) {
            $query .= " WHERE s.status = ?";
            $stmt = $this->db->prepare($query);
            $stmt->bind_param("s", $status);
        } else {
            $stmt = $this->db->prepare($query);
        }
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        $subscriptions = [];
        while ($row = $result->fetch_assoc()) {
            $subscriptions[] = $row;
        }
        
        $stmt->close();
        return $subscriptions;
    }
    
    /**
     * عدد الاشتراكات النشطة
     * 
     * @return int عدد الاشتراكات النشطة
     */
    public function countActiveSubscriptions() {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM subscriptions WHERE status = 'active' AND end_date >= CURDATE()");
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        $stmt->close();
        return $row['count'];
    }
    
    /**
     * إجمالي الإيرادات
     * 
     * @param string $period الفترة (all, month, year)
     * @return float إجمالي الإيرادات
     */
    public function getTotalRevenue($period = 'all') {
        // بناء الاستعلام
        $query = "SELECT SUM(amount) as total FROM subscriptions";
        
        if ($period === 'month') {
            $query .= " WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())";
        } elseif ($period === 'year') {
            $query .= " WHERE YEAR(created_at) = YEAR(CURRENT_DATE())";
        }
        
        // إعداد الاستعلام
        $stmt = $this->db->prepare($query);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        $stmt->close();
        return $row['total'] ? $row['total'] : 0;
    }
}
?>
