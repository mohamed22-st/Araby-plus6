<?php
// تكوين عام للتطبيق
define('APP_NAME', 'عربي بلس');
define('APP_URL', 'http://localhost/arabic_plus');
define('APP_ROOT', dirname(dirname(__DIR__)));
define('UPLOAD_PATH', APP_ROOT . '/assets/uploads');
define('VIDEO_PATH', UPLOAD_PATH . '/videos');

// تكوين الجلسة
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
session_start();

// وظائف مساعدة

/**
 * توجيه المستخدم إلى صفحة معينة
 */
function redirect($page) {
    header('Location: ' . APP_URL . '/' . $page);
    exit;
}

/**
 * التحقق من تسجيل دخول المستخدم
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * التحقق من صلاحيات المسؤول
 */
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * عرض رسالة خطأ
 */
function flashError($message) {
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = 'error';
}

/**
 * عرض رسالة نجاح
 */
function flashSuccess($message) {
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = 'success';
}

/**
 * عرض رسالة تنبيه
 */
function flashWarning($message) {
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = 'warning';
}

/**
 * عرض رسالة معلومات
 */
function flashInfo($message) {
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = 'info';
}

/**
 * عرض رسالة الفلاش إذا كانت موجودة
 */
function displayFlashMessage() {
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        $type = $_SESSION['flash_type'];
        
        echo "<div class='alert alert-{$type}'>{$message}</div>";
        
        // حذف الرسالة بعد عرضها
        unset($_SESSION['flash_message']);
        unset($_SESSION['flash_type']);
    }
}

/**
 * تنظيف المدخلات
 */
function sanitize($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input);
    return $input;
}

/**
 * التحقق من صلاحية الاشتراك
 */
function hasValidSubscription() {
    if (!isLoggedIn()) {
        return false;
    }
    
    require_once APP_ROOT . '/src/models/Subscription.php';
    $subscription = new Subscription();
    return $subscription->isActive($_SESSION['user_id']);
}

/**
 * تحويل التاريخ إلى الصيغة العربية
 */
function formatArabicDate($date) {
    $months = [
        'January' => 'يناير',
        'February' => 'فبراير',
        'March' => 'مارس',
        'April' => 'أبريل',
        'May' => 'مايو',
        'June' => 'يونيو',
        'July' => 'يوليو',
        'August' => 'أغسطس',
        'September' => 'سبتمبر',
        'October' => 'أكتوبر',
        'November' => 'نوفمبر',
        'December' => 'ديسمبر'
    ];
    
    $englishDate = date('j F Y', strtotime($date));
    
    foreach ($months as $english => $arabic) {
        $englishDate = str_replace($english, $arabic, $englishDate);
    }
    
    return $englishDate;
}

/**
 * تحويل الوقت إلى الصيغة العربية
 */
function formatDuration($seconds) {
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    
    if ($hours > 0) {
        return $hours . ' ساعة و ' . $minutes . ' دقيقة';
    } else {
        return $minutes . ' دقيقة';
    }
}

/**
 * اختصار النص
 */
function truncateText($text, $length = 100) {
    if (strlen($text) <= $length) {
        return $text;
    }
    
    $text = substr($text, 0, $length);
    $text = substr($text, 0, strrpos($text, ' '));
    return $text . '...';
}

// تضمين ملف قاعدة البيانات
require_once 'database.php';
?>
