<?php
// تضمين ملف التكوين
require_once '../src/config/config.php';

// التحقق من وجود معرف الدورة
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    redirect('courses.php');
}

$courseId = (int)$_GET['id'];

// تضمين النماذج المطلوبة
require_once '../src/models/Course.php';
require_once '../src/models/Video.php';
require_once '../src/models/Subscription.php';

// إنشاء كائنات النماذج
$courseModel = new Course();
$videoModel = new Video();
$subscriptionModel = new Subscription();

// الحصول على بيانات الدورة
$course = $courseModel->getCourseById($courseId);

// التحقق من وجود الدورة
if (!$course) {
    flashError('الدورة غير موجودة');
    redirect('courses.php');
}

// الحصول على قائمة الفيديوهات
$videos = $videoModel->getVideosByCourse($courseId);

// التحقق من صلاحية الاشتراك للوصول إلى المحتوى
$hasAccess = isLoggedIn() && hasValidSubscription();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $course['title']; ?> - عربي بلس</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Tajawal:wght@400;500;700&display=swap">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- القائمة العلوية -->
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <img src="../assets/images/logo.png" alt="عربي بلس" onerror="this.src='../assets/images/logo-placeholder.png'">
                </a>
                
                <ul class="nav-links">
                    <li><a href="index.php">الرئيسية</a></li>
                    <li><a href="courses.php" class="active">الدورات</a></li>
                    <li><a href="subscription.php">الاشتراكات</a></li>
                    <li><a href="about.php">عن المنصة</a></li>
                    <li><a href="contact.php">اتصل بنا</a></li>
                </ul>
                
                <div class="auth-buttons">
                    <?php if (isLoggedIn()): ?>
                        <a href="dashboard.php" class="btn btn-outline">لوحة التحكم</a>
                        <a href="logout.php" class="btn btn-primary">تسجيل الخروج</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-outline">تسجيل الدخول</a>
                        <a href="register.php" class="btn btn-primary">إنشاء حساب</a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>
    
    <!-- تفاصيل الدورة -->
    <section class="section course-details-section">
        <div class="container">
            <?php displayFlashMessage(); ?>
            
            <div class="course-header">
                <div class="course-info">
                    <h1 class="course-title"><?php echo $course['title']; ?></h1>
                    <div class="course-meta">
                        <span class="course-grade"><?php echo $course['grade']; ?></span>
                        <span class="course-type"><?php echo $course['type'] === 'azhar' ? 'الأزهر' : 'التعليم العام'; ?></span>
                    </div>
                </div>
                
                <?php if (!isLoggedIn()): ?>
                    <div class="course-actions">
                        <a href="login.php?redirect=course-details.php?id=<?php echo $courseId; ?>" class="btn btn-primary">تسجيل الدخول للمشاهدة</a>
                    </div>
                <?php elseif (!$hasAccess): ?>
                    <div class="course-actions">
                        <a href="subscription.php" class="btn btn-primary">اشترك الآن للمشاهدة</a>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="course-content">
                <div class="course-description">
                    <h2>وصف الدورة</h2>
                    <p><?php echo nl2br($course['description']); ?></p>
                </div>
                
                <div class="course-videos">
                    <h2>محتوى الدورة</h2>
                    
                    <?php if (empty($videos)): ?>
                        <p class="no-videos">لا يوجد محتوى متاح حاليًا لهذه الدورة</p>
                    <?php else: ?>
                        <div class="videos-list">
                            <?php foreach ($videos as $index => $video): ?>
                                <div class="video-item">
                                    <div class="video-info">
                                        <span class="video-number"><?php echo $index + 1; ?></span>
                                        <h3 class="video-title"><?php echo $video['title']; ?></h3>
                                        <?php if ($video['duration']): ?>
                                            <span class="video-duration"><?php echo $video['duration']; ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php if ($hasAccess): ?>
                                        <a href="video.php?id=<?php echo $video['id']; ?>" class="btn btn-sm btn-primary">مشاهدة</a>
                                    <?php else: ?>
                                        <button class="btn btn-sm btn-outline" disabled>مشاهدة</button>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php if (!$hasAccess): ?>
                <div class="subscription-cta">
                    <h2>اشترك الآن للوصول إلى جميع الدورات</h2>
                    <p>احصل على وصول غير محدود إلى جميع دوراتنا التعليمية في اللغة العربية للمراحل الإعدادية والثانوية</p>
                    <a href="subscription.php" class="btn btn-primary">عرض خطط الاشتراك</a>
                </div>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- التذييل -->
    <footer>
        <div class="container">
            <ul class="footer-links">
                <li><a href="index.php">الرئيسية</a></li>
                <li><a href="courses.php">الدورات</a></li>
                <li><a href="subscription.php">الاشتراكات</a></li>
                <li><a href="about.php">عن المنصة</a></li>
                <li><a href="contact.php">اتصل بنا</a></li>
                <li><a href="privacy.php">سياسة الخصوصية</a></li>
                <li><a href="terms.php">شروط الاستخدام</a></li>
            </ul>
            
            <div class="copyright">
                &copy; <?php echo date('Y'); ?> عربي بلس - جميع الحقوق محفوظة
            </div>
        </div>
    </footer>
    
    <script src="../assets/js/main.js"></script>
</body>
</html>
