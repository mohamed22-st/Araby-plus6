<?php
// تضمين ملف التكوين
require_once '../src/config/config.php';

// التحقق من تسجيل الدخول وصلاحيات المسؤول
if (!isLoggedIn() || !isAdmin()) {
    flashError('غير مصرح لك بالوصول إلى لوحة التحكم');
    redirect('login.php');
}

// تضمين النماذج المطلوبة
require_once '../src/models/User.php';
require_once '../src/models/Course.php';
require_once '../src/models/Subscription.php';

// إنشاء كائنات النماذج
$userModel = new User();
$courseModel = new Course();
$subscriptionModel = new Subscription();

// الحصول على إحصائيات لوحة التحكم
$totalUsers = $userModel->countUsers();
$totalStudents = $userModel->countUsers('student');
$totalCourses = $courseModel->countCourses();
$activeSubscriptions = $subscriptionModel->countActiveSubscriptions();
$monthlyRevenue = $subscriptionModel->getTotalRevenue('month');
$yearlyRevenue = $subscriptionModel->getTotalRevenue('year');
$totalRevenue = $subscriptionModel->getTotalRevenue();
$newUsers = $userModel->getNewUsersCount(30);

// تحديد القسم النشط
$section = isset($_GET['section']) ? $_GET['section'] : 'dashboard';
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - عربي بلس</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Tajawal:wght@400;500;700&display=swap">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="admin-container">
        <!-- القائمة الجانبية -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>عربي بلس</h2>
                <p>لوحة تحكم المالك</p>
            </div>
            
            <ul class="sidebar-menu">
                <li class="<?php echo $section === 'dashboard' ? 'active' : ''; ?>">
                    <a href="admin.php?section=dashboard">
                        <span class="icon">📊</span>
                        <span class="text">لوحة المعلومات</span>
                    </a>
                </li>
                <li class="<?php echo $section === 'users' ? 'active' : ''; ?>">
                    <a href="admin.php?section=users">
                        <span class="icon">👥</span>
                        <span class="text">إدارة المستخدمين</span>
                    </a>
                </li>
                <li class="<?php echo $section === 'courses' ? 'active' : ''; ?>">
                    <a href="admin.php?section=courses">
                        <span class="icon">📚</span>
                        <span class="text">إدارة الدورات</span>
                    </a>
                </li>
                <li class="<?php echo $section === 'videos' ? 'active' : ''; ?>">
                    <a href="admin.php?section=videos">
                        <span class="icon">🎬</span>
                        <span class="text">إدارة الفيديوهات</span>
                    </a>
                </li>
                <li class="<?php echo $section === 'subscriptions' ? 'active' : ''; ?>">
                    <a href="admin.php?section=subscriptions">
                        <span class="icon">💳</span>
                        <span class="text">إدارة الاشتراكات</span>
                    </a>
                </li>
                <li class="<?php echo $section === 'settings' ? 'active' : ''; ?>">
                    <a href="admin.php?section=settings">
                        <span class="icon">⚙️</span>
                        <span class="text">الإعدادات</span>
                    </a>
                </li>
                <li>
                    <a href="index.php">
                        <span class="icon">🏠</span>
                        <span class="text">العودة للموقع</span>
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <span class="icon">🚪</span>
                        <span class="text">تسجيل الخروج</span>
                    </a>
                </li>
            </ul>
        </div>
        
        <!-- المحتوى الرئيسي -->
        <div class="admin-content">
            <div id="admin-alerts"></div>
            
            <?php displayFlashMessage(); ?>
            
            <?php if ($section === 'dashboard'): ?>
                <!-- لوحة المعلومات -->
                <div class="admin-header">
                    <h1 class="admin-title">لوحة المعلومات</h1>
                </div>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">👥</div>
                        <div class="stat-value"><?php echo $totalUsers; ?></div>
                        <div class="stat-label">إجمالي المستخدمين</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">🧑‍🎓</div>
                        <div class="stat-value"><?php echo $totalStudents; ?></div>
                        <div class="stat-label">إجمالي الطلاب</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">📚</div>
                        <div class="stat-value"><?php echo $totalCourses; ?></div>
                        <div class="stat-label">إجمالي الدورات</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">💳</div>
                        <div class="stat-value"><?php echo $activeSubscriptions; ?></div>
                        <div class="stat-label">الاشتراكات النشطة</div>
                    </div>
                </div>
                
                <div class="admin-card">
                    <h2>الإيرادات</h2>
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-value"><?php echo number_format($monthlyRevenue, 2); ?> جنيه</div>
                            <div class="stat-label">إيرادات الشهر الحالي</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-value"><?php echo number_format($yearlyRevenue, 2); ?> جنيه</div>
                            <div class="stat-label">إيرادات السنة الحالية</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-value"><?php echo number_format($totalRevenue, 2); ?> جنيه</div>
                            <div class="stat-label">إجمالي الإيرادات</div>
                        </div>
                    </div>
                </div>
                
                <div class="admin-card">
                    <h2>المستخدمين الجدد (آخر 30 يوم)</h2>
                    <div class="stat-value"><?php echo $newUsers; ?> مستخدم</div>
                </div>
                
            <?php elseif ($section === 'users'): ?>
                <!-- إدارة المستخدمين -->
                <div class="admin-header">
                    <h1 class="admin-title">إدارة المستخدمين</h1>
                    <a href="admin.php?section=users&action=add" class="btn btn-primary">إضافة مستخدم جديد</a>
                </div>
                
                <?php
                // التحقق من الإجراء
                $action = isset($_GET['action']) ? $_GET['action'] : 'list';
                
                if ($action === 'add' || ($action === 'edit' && isset($_GET['id']))):
                    // نموذج إضافة/تعديل مستخدم
                    $userId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
                    $user = $userId > 0 ? $userModel->getUserById($userId) : null;
                    $formTitle = $userId > 0 ? 'تعديل مستخدم' : 'إضافة مستخدم جديد';
                ?>
                
                <div class="admin-card">
                    <h2><?php echo $formTitle; ?></h2>
                    
                    <form action="admin_actions.php" method="POST" class="admin-form">
                        <input type="hidden" name="action" value="<?php echo $userId > 0 ? 'update_user' : 'add_user'; ?>">
                        <?php if ($userId > 0): ?>
                            <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <label for="full_name">الاسم الكامل</label>
                            <input type="text" id="full_name" name="full_name" class="form-control" value="<?php echo $user ? $user['full_name'] : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">البريد الإلكتروني</label>
                            <input type="email" id="email" name="email" class="form-control" value="<?php echo $user ? $user['email'] : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="username">اسم المستخدم</label>
                            <input type="text" id="username" name="username" class="form-control" value="<?php echo $user ? $user['username'] : ''; ?>" <?php echo $userId > 0 ? 'readonly' : 'required'; ?>>
                        </div>
                        
                        <?php if ($userId === 0): ?>
                            <div class="form-group">
                                <label for="password">كلمة المرور</label>
                                <input type="password" id="password" name="password" class="form-control" required>
                            </div>
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <label for="role">الدور</label>
                            <select id="role" name="role" class="form-control" required>
                                <option value="student" <?php echo $user && $user['role'] === 'student' ? 'selected' : ''; ?>>طالب</option>
                                <option value="admin" <?php echo $user && $user['role'] === 'admin' ? 'selected' : ''; ?>>مسؤول</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">حفظ</button>
                            <a href="admin.php?section=users" class="btn btn-outline">إلغاء</a>
                        </div>
                    </form>
                </div>
                
                <?php else: ?>
                    <!-- قائمة المستخدمين -->
                    <div class="admin-card">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>اسم المستخدم</th>
                                        <th>الاسم الكامل</th>
                                        <th>البريد الإلكتروني</th>
                                        <th>الدور</th>
                                        <th>تاريخ التسجيل</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $users = $userModel->getAllUsers();
                                    foreach ($users as $index => $user):
                                    ?>
                                    <tr id="user-<?php echo $user['id']; ?>">
                                        <td><?php echo $index + 1; ?></td>
                                        <td><?php echo $user['username']; ?></td>
                                        <td><?php echo $user['full_name']; ?></td>
                                        <td><?php echo $user['email']; ?></td>
                                        <td><?php echo $user['role'] === 'admin' ? 'مسؤول' : 'طالب'; ?></td>
                                        <td><?php echo formatArabicDate($user['created_at']); ?></td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="admin.php?section=users&action=edit&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-warning">تعديل</a>
                                                <button onclick="deleteItem(<?php echo $user['id']; ?>, 'user')" class="btn btn-sm btn-danger">حذف</button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    
                                    <?php if (empty($users)): ?>
                                        <tr>
                                            <td colspan="7" class="text-center">لا يوجد مستخدمين</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
                
            <?php elseif ($section === 'courses'): ?>
                <!-- إدارة الدورات -->
                <div class="admin-header">
                    <h1 class="admin-title">إدارة الدورات</h1>
                    <a href="admin.php?section=courses&action=add" class="btn btn-primary">إضافة دورة جديدة</a>
                </div>
                
                <?php
                // التحقق من الإجراء
                $action = isset($_GET['action']) ? $_GET['action'] : 'list';
                
                if ($action === 'add' || ($action === 'edit' && isset($_GET['id']))):
                    // نموذج إضافة/تعديل دورة
                    $courseId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
                    $course = $courseId > 0 ? $courseModel->getCourseById($courseId) : null;
                    $formTitle = $courseId > 0 ? 'تعديل دورة' : 'إضافة دورة جديدة';
                ?>
                
                <div class="admin-card">
                    <h2><?php echo $formTitle; ?></h2>
                    
                    <form action="admin_actions.php" method="POST" class="admin-form" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="<?php echo $courseId > 0 ? 'update_course' : 'add_course'; ?>">
                        <?php if ($courseId > 0): ?>
                            <input type="hidden" name="course_id" value="<?php echo $courseId; ?>">
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <label for="title">عنوان الدورة</label>
                            <input type="text" id="title" name="title" class="form-control" value="<?php echo $course ? $course['title'] : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="description">وصف الدورة</label>
                            <textarea id="description" name="description" class="form-control" rows="5" required><?php echo $course ? $course['description'] : ''; ?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="grade">الصف الدراسي</label>
                            <select id="grade" name="grade" class="form-control" required>
                                <option value="">اختر الصف الدراسي</option>
                                <optgroup label="المرحلة الإعدادية">
                                    <option value="الصف الأول الإعدادي" <?php echo $course && $course['grade'] === 'الصف الأول الإعدادي' ? 'selected' : ''; ?>>الصف الأول الإعدادي</option>
                                    <option value="الصف الثاني الإعدادي" <?php echo $course && $course['grade'] === 'الصف الثاني الإعدادي' ? 'selected' : ''; ?>>الصف الثاني الإعدادي</option>
                                    <option value="الصف الثالث الإعدادي" <?php echo $course && $course['grade'] === 'الصف الثالث الإعدادي' ? 'selected' : ''; ?>>الصف الثالث الإعدادي</option>
                                </optgroup>
                                <optgroup label="المرحلة الثانوية">
                                    <option value="الصف الأول الثانوي" <?php echo $course && $course['grade'] === 'الصف الأول الثانوي' ? 'selected' : ''; ?>>الصف الأول الثانوي</option>
                                    <option value="الصف الثاني الثانوي" <?php echo $course && $course['grade'] === 'الصف الثاني الثانوي' ? 'selected' : ''; ?>>الصف الثاني الثانوي</option>
                                    <option value="الصف الثالث الثانوي" <?php echo $course && $course['grade'] === 'الصف الثالث الثانوي' ? 'selected' : ''; ?>>الصف الثالث الثانوي</option>
                                </optgroup>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="type">نوع الدورة</label>
                            <select id="type" name="type" class="form-control" required>
                                <option value="general" <?php echo $course && $course['type'] === 'general' ? 'selected' : ''; ?>>التعليم العام</option>
                                <option value="azhar" <?php echo $course && $course['type'] === 'azhar' ? 'selected' : ''; ?>>الأزهر</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="thumbnail">الصورة المصغرة</label>
                            <?php if ($course && $course['thumbnail']): ?>
                                <div class="current-thumbnail">
                                    <img src="<?php echo '../' . $course['thumbnail']; ?>" alt="<?php echo $course['title']; ?>" width="200">
                                    <p>الصورة الحالية</p>
                                </div>
                            <?php endif; ?>
                            <input type="file" id="thumbnail" name="thumbnail" class="form-control file-uploader" accept="image/*">
                            <span class="file-name"><?php echo $course && $course['thumbnail'] ? basename($course['thumbnail']) : 'لم يتم اختيار ملف'; ?></span>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">حفظ</button>
                            <a href="admin.php?section=courses" class="btn btn-outline">إلغاء</a>
                        </div>
                    </form>
                </div>
                
                <?php else: ?>
                    <!-- قائمة الدورات -->
                    <div class="admin-card">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>الصورة</th>
                                        <th>العنوان</th>
                                        <th>الصف الدراسي</th>
                                        <th>النوع</th>
                                        <th>تاريخ الإنشاء</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $courses = $courseModel->getAllCourses();
                                    foreach ($courses as $index => $course):
                                    ?>
                                    <tr id="course-<?php echo $course['id']; ?>">
                                        <td><?php echo $index + 1; ?></td>
                                        <td>
                                            <img src="<?php echo $course['thumbnail'] ? '../' . $course['thumbnail'] : '../assets/images/course-placeholder.jpg'; ?>" alt="<?php echo $course['title']; ?>" width="50" height="50" style="object-fit: cover;">
                                        </td>
                                        <td><?php echo $course['title']; ?></td>
                                        <td><?php echo $course['grade']; ?></td>
                                        <td><?php echo $course['type'] === 'azhar' ? 'الأزهر' : 'التعليم العام'; ?></td>
                                        <td><?php echo formatArabicDate($course['created_at']); ?></td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="admin.php?section=courses&action=edit&id=<?php echo $course['id']; ?>" class="btn btn-sm btn-warning">تعديل</a>
                                                <a href="admin.php?section=videos&course_id=<?php echo $course['id']; ?>" class="btn btn-sm btn-primary">الفيديوهات</a>
                                                <button onclick="deleteItem(<?php echo $course['id']; ?>, 'course')" class="btn btn-sm btn-danger">حذف</button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    
                                    <?php if (empty($courses)): ?>
                                        <tr>
                                            <td colspan="7" class="text-center">لا توجد دورات</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
                
            <?php elseif ($section === 'videos'): ?>
                <!-- إدارة الفيديوهات -->
                <div class="admin-header">
                    <h1 class="admin-title">إدارة الفيديوهات</h1>
                    <?php if (isset($_GET['course_id'])): ?>
                        <a href="admin.php?section=videos&action=add&course_id=<?php echo $_GET['course_id']; ?>" class="btn btn-primary">إضافة فيديو جديد</a>
                    <?php endif; ?>
                </div>
                
                <?php
                // التحقق من الإجراء
                $action = isset($_GET['action']) ? $_GET['action'] : 'list';
                $courseId = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
                
                if ($courseId > 0):
                    $course = $courseModel->getCourseById($courseId);
                    
                    if ($action === 'add' || ($action === 'edit' && isset($_GET['id']))):
                        // نموذج إضافة/تعديل فيديو
                        $videoId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
                        // هنا يمكن إضافة كود للحصول على بيانات الفيديو إذا كان التعديل
                        $formTitle = $videoId > 0 ? 'تعديل فيديو' : 'إضافة فيديو جديد';
                ?>
                
                <div class="admin-card">
                    <h2><?php echo $formTitle; ?> - <?php echo $course['title']; ?></h2>
                    
                    <form action="admin_actions.php" method="POST" class="admin-form" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="<?php echo $videoId > 0 ? 'update_video' : 'add_video'; ?>">
                        <input type="hidden" name="course_id" value="<?php echo $courseId; ?>">
                        <?php if ($videoId > 0): ?>
                            <input type="hidden" name="video_id" value="<?php echo $videoId; ?>">
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <label for="title">عنوان الفيديو</label>
                            <input type="text" id="title" name="title" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="description">وصف الفيديو</label>
                            <textarea id="description" name="description" class="form-control" rows="3"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="video_file">ملف الفيديو</label>
                            <input type="file" id="video_file" name="video_file" class="form-control file-uploader" accept="video/*" <?php echo $videoId > 0 ? '' : 'required'; ?>>
                            <span class="file-name">لم يتم اختيار ملف</span>
                            <p class="help-text">الحد الأقصى لحجم الملف: 500 ميجابايت</p>
                        </div>
                        
                        <div class="form-group">
                            <label for="order_num">ترتيب الفيديو</label>
                            <input type="number" id="order_num" name="order_num" class="form-control" min="0" value="0">
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">حفظ</button>
                            <a href="admin.php?section=videos&course_id=<?php echo $courseId; ?>" class="btn btn-outline">إلغاء</a>
                        </div>
                    </form>
                </div>
                
                <?php else: ?>
                    <!-- قائمة الفيديوهات للدورة المحددة -->
                    <div class="admin-card">
                        <h2>فيديوهات دورة: <?php echo $course['title']; ?></h2>
                        
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>العنوان</th>
                                        <th>المدة</th>
                                        <th>الترتيب</th>
                                        <th>تاريخ الإضافة</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- هنا يمكن إضافة كود لعرض قائمة الفيديوهات -->
                                    <tr>
                                        <td colspan="6" class="text-center">لا توجد فيديوهات لهذه الدورة</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="form-group">
                            <a href="admin.php?section=courses" class="btn btn-outline">العودة إلى قائمة الدورات</a>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php else: ?>
                    <!-- قائمة الدورات لاختيار دورة لإدارة فيديوهاتها -->
                    <div class="admin-card">
                        <h2>اختر دورة لإدارة فيديوهاتها</h2>
                        
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>العنوان</th>
                                        <th>الصف الدراسي</th>
                                        <th>النوع</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $courses = $courseModel->getAllCourses();
                                    foreach ($courses as $index => $course):
                                    ?>
                                    <tr>
                                        <td><?php echo $index + 1; ?></td>
                                        <td><?php echo $course['title']; ?></td>
                                        <td><?php echo $course['grade']; ?></td>
                                        <td><?php echo $course['type'] === 'azhar' ? 'الأزهر' : 'التعليم العام'; ?></td>
                                        <td>
                                            <a href="admin.php?section=videos&course_id=<?php echo $course['id']; ?>" class="btn btn-sm btn-primary">إدارة الفيديوهات</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    
                                    <?php if (empty($courses)): ?>
                                        <tr>
                                            <td colspan="5" class="text-center">لا توجد دورات</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
                
            <?php elseif ($section === 'subscriptions'): ?>
                <!-- إدارة الاشتراكات -->
                <div class="admin-header">
                    <h1 class="admin-title">إدارة الاشتراكات</h1>
                </div>
                
                <div class="admin-card">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>المستخدم</th>
                                    <th>نوع الخطة</th>
                                    <th>المبلغ</th>
                                    <th>طريقة الدفع</th>
                                    <th>تاريخ البداية</th>
                                    <th>تاريخ الانتهاء</th>
                                    <th>الحالة</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $subscriptions = $subscriptionModel->getAllSubscriptions();
                                foreach ($subscriptions as $index => $subscription):
                                    $statusClass = '';
                                    $statusText = '';
                                    
                                    switch ($subscription['status']) {
                                        case 'active':
                                            $statusClass = 'status-active';
                                            $statusText = 'نشط';
                                            break;
                                        case 'expired':
                                            $statusClass = 'status-expired';
                                            $statusText = 'منتهي';
                                            break;
                                        case 'cancelled':
                                            $statusClass = 'status-cancelled';
                                            $statusText = 'ملغي';
                                            break;
                                    }
                                ?>
                                <tr id="subscription-<?php echo $subscription['id']; ?>">
                                    <td><?php echo $index + 1; ?></td>
                                    <td><?php echo $subscription['full_name']; ?> (<?php echo $subscription['username']; ?>)</td>
                                    <td>
                                        <?php
                                        switch ($subscription['plan_type']) {
                                            case 'monthly':
                                                echo 'شهري';
                                                break;
                                            case 'quarterly':
                                                echo 'ربع سنوي';
                                                break;
                                            case 'yearly':
                                                echo 'سنوي';
                                                break;
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo number_format($subscription['amount'], 2); ?> جنيه</td>
                                    <td><?php echo $subscription['payment_method']; ?></td>
                                    <td><?php echo formatArabicDate($subscription['start_date']); ?></td>
                                    <td><?php echo formatArabicDate($subscription['end_date']); ?></td>
                                    <td><span class="status-badge <?php echo $statusClass; ?>"><?php echo $statusText; ?></span></td>
                                    <td>
                                        <div class="action-buttons">
                                            <?php if ($subscription['status'] === 'active'): ?>
                                                <button onclick="cancelSubscription(<?php echo $subscription['id']; ?>)" class="btn btn-sm btn-warning">إلغاء</button>
                                            <?php endif; ?>
                                            <button onclick="deleteItem(<?php echo $subscription['id']; ?>, 'subscription')" class="btn btn-sm btn-danger">حذف</button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($subscriptions)): ?>
                                    <tr>
                                        <td colspan="9" class="text-center">لا توجد اشتراكات</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
            <?php elseif ($section === 'settings'): ?>
                <!-- الإعدادات -->
                <div class="admin-header">
                    <h1 class="admin-title">إعدادات المنصة</h1>
                </div>
                
                <div class="admin-card">
                    <h2>إعدادات الحساب</h2>
                    
                    <form action="admin_actions.php" method="POST" class="admin-form">
                        <input type="hidden" name="action" value="update_admin_password">
                        
                        <div class="form-group">
                            <label for="current_password">كلمة المرور الحالية</label>
                            <input type="password" id="current_password" name="current_password" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password">كلمة المرور الجديدة</label>
                            <input type="password" id="new_password" name="new_password" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">تأكيد كلمة المرور الجديدة</label>
                            <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">تغيير كلمة المرور</button>
                        </div>
                    </form>
                </div>
                
                <div class="admin-card">
                    <h2>إعدادات الاشتراكات</h2>
                    
                    <form action="admin_actions.php" method="POST" class="admin-form">
                        <input type="hidden" name="action" value="update_subscription_settings">
                        
                        <div class="form-group">
                            <label for="monthly_price">سعر الاشتراك الشهري (جنيه)</label>
                            <input type="number" id="monthly_price" name="monthly_price" class="form-control" min="0" step="0.01" value="100" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="quarterly_price">سعر الاشتراك الربع سنوي (جنيه)</label>
                            <input type="number" id="quarterly_price" name="quarterly_price" class="form-control" min="0" step="0.01" value="250" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="yearly_price">سعر الاشتراك السنوي (جنيه)</label>
                            <input type="number" id="yearly_price" name="yearly_price" class="form-control" min="0" step="0.01" value="900" required>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">حفظ الإعدادات</button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="../assets/js/main.js"></script>
</body>
</html>
