<?php
// تكوين قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'arabic_plus');

// محاولة الاتصال بقاعدة البيانات
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);

// التحقق من وجود أخطاء في الاتصال
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}

// إنشاء قاعدة البيانات إذا لم تكن موجودة
$sql = "CREATE DATABASE IF NOT EXISTS " . DB_NAME;
if ($conn->query($sql) === FALSE) {
    die("خطأ في إنشاء قاعدة البيانات: " . $conn->error);
}

// اختيار قاعدة البيانات
$conn->select_db(DB_NAME);

// إنشاء جدول المستخدمين إذا لم يكن موجودًا
$sql = "CREATE TABLE IF NOT EXISTS users (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'student') NOT NULL DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === FALSE) {
    die("خطأ في إنشاء جدول المستخدمين: " . $conn->error);
}

// إنشاء جدول الدورات إذا لم يكن موجودًا
$sql = "CREATE TABLE IF NOT EXISTS courses (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    grade VARCHAR(50) NOT NULL,
    type ENUM('azhar', 'general') NOT NULL,
    thumbnail VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === FALSE) {
    die("خطأ في إنشاء جدول الدورات: " . $conn->error);
}

// إنشاء جدول الفيديوهات إذا لم يكن موجودًا
$sql = "CREATE TABLE IF NOT EXISTS videos (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    course_id INT(11) UNSIGNED NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    file_path VARCHAR(255) NOT NULL,
    duration VARCHAR(10),
    order_num INT(11) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
)";

if ($conn->query($sql) === FALSE) {
    die("خطأ في إنشاء جدول الفيديوهات: " . $conn->error);
}

// إنشاء جدول الاشتراكات إذا لم يكن موجودًا
$sql = "CREATE TABLE IF NOT EXISTS subscriptions (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) UNSIGNED NOT NULL,
    plan_type ENUM('monthly', 'quarterly', 'yearly') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    transaction_id VARCHAR(100),
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status ENUM('active', 'expired', 'cancelled') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
)";

if ($conn->query($sql) === FALSE) {
    die("خطأ في إنشاء جدول الاشتراكات: " . $conn->error);
}

// إنشاء حساب المسؤول الافتراضي إذا لم يكن موجودًا
$admin_username = 'admin';
$admin_password = password_hash('admin123', PASSWORD_DEFAULT);
$admin_email = 'admin@arabicplus.com';
$admin_name = 'مدير المنصة';

// التحقق من وجود المسؤول
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $admin_username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    // إنشاء حساب المسؤول
    $stmt = $conn->prepare("INSERT INTO users (username, password, email, full_name, role) VALUES (?, ?, ?, ?, 'admin')");
    $stmt->bind_param("ssss", $admin_username, $admin_password, $admin_email, $admin_name);
    
    if ($stmt->execute() === FALSE) {
        echo "خطأ في إنشاء حساب المسؤول: " . $stmt->error;
    } else {
        echo "تم إنشاء حساب المسؤول بنجاح.<br>";
    }
}

$stmt->close();
$conn->close();

echo "تم إعداد قاعدة البيانات بنجاح.";
?>
