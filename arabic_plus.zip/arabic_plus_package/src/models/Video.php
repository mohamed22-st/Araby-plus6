<?php
/**
 * نموذج الفيديو
 * يتعامل مع عمليات الفيديوهات مثل إنشاء وتعديل وحذف الفيديوهات
 */
class Video {
    private $db;
    
    /**
     * المُنشئ - يقوم بإنشاء اتصال بقاعدة البيانات
     */
    public function __construct() {
        $this->db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($this->db->connect_error) {
            die("فشل الاتصال بقاعدة البيانات: " . $this->db->connect_error);
        }
    }
    
    /**
     * إنشاء فيديو جديد
     * 
     * @param int $courseId معرف الدورة
     * @param string $title عنوان الفيديو
     * @param string $description وصف الفيديو
     * @param string $filePath مسار ملف الفيديو
     * @param string $duration مدة الفيديو
     * @param int $orderNum ترتيب الفيديو
     * @return bool|int معرف الفيديو الجديد أو false في حالة الفشل
     */
    public function createVideo($courseId, $title, $description, $filePath, $duration = null, $orderNum = 0) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("INSERT INTO videos (course_id, title, description, file_path, duration, order_num) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssi", $courseId, $title, $description, $filePath, $duration, $orderNum);
        
        // تنفيذ الاستعلام
        if ($stmt->execute()) {
            $videoId = $stmt->insert_id;
            $stmt->close();
            return $videoId;
        } else {
            $stmt->close();
            return false;
        }
    }
    
    /**
     * تحديث فيديو
     * 
     * @param int $id معرف الفيديو
     * @param array $data البيانات المراد تحديثها
     * @return bool نجاح أو فشل العملية
     */
    public function updateVideo($id, $data) {
        // بناء استعلام التحديث
        $query = "UPDATE videos SET ";
        $params = [];
        $types = "";
        
        foreach ($data as $key => $value) {
            if ($key !== 'id') {
                $query .= "$key = ?, ";
                $params[] = $value;
                
                // تحديد نوع البيانات
                if (is_int($value)) {
                    $types .= "i";
                } elseif (is_double($value)) {
                    $types .= "d";
                } else {
                    $types .= "s";
                }
            }
        }
        
        // إزالة الفاصلة الأخيرة والمسافة
        $query = rtrim($query, ", ");
        
        // إضافة شرط WHERE
        $query .= " WHERE id = ?";
        $params[] = $id;
        $types .= "i";
        
        // إعداد الاستعلام
        $stmt = $this->db->prepare($query);
        
        // ربط المعلمات
        $stmt->bind_param($types, ...$params);
        
        // تنفيذ الاستعلام
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    }
    
    /**
     * حذف فيديو
     * 
     * @param int $id معرف الفيديو
     * @return bool نجاح أو فشل العملية
     */
    public function deleteVideo($id) {
        // الحصول على مسار الملف قبل الحذف
        $stmt = $this->db->prepare("SELECT file_path FROM videos WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $video = $result->fetch_assoc();
            $filePath = $video['file_path'];
            $stmt->close();
            
            // حذف السجل من قاعدة البيانات
            $stmt = $this->db->prepare("DELETE FROM videos WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                $stmt->close();
                
                // حذف ملف الفيديو من الخادم إذا كان موجودًا
                if (file_exists(APP_ROOT . '/' . $filePath)) {
                    unlink(APP_ROOT . '/' . $filePath);
                }
                
                return true;
            } else {
                $stmt->close();
                return false;
            }
        } else {
            $stmt->close();
            return false;
        }
    }
    
    /**
     * الحصول على فيديو باستخدام المعرف
     * 
     * @param int $id معرف الفيديو
     * @return bool|array بيانات الفيديو أو false إذا لم يتم العثور عليه
     */
    public function getVideoById($id) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT * FROM videos WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $video = $result->fetch_assoc();
            $stmt->close();
            return $video;
        }
        
        $stmt->close();
        return false;
    }
    
    /**
     * الحصول على جميع فيديوهات دورة معينة
     * 
     * @param int $courseId معرف الدورة
     * @return array قائمة الفيديوهات
     */
    public function getVideosByCourse($courseId) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT * FROM videos WHERE course_id = ? ORDER BY order_num ASC, created_at ASC");
        $stmt->bind_param("i", $courseId);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        $videos = [];
        while ($row = $result->fetch_assoc()) {
            $videos[] = $row;
        }
        
        $stmt->close();
        return $videos;
    }
    
    /**
     * عدد الفيديوهات في دورة معينة
     * 
     * @param int $courseId معرف الدورة
     * @return int عدد الفيديوهات
     */
    public function countVideosByCourse($courseId) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM videos WHERE course_id = ?");
        $stmt->bind_param("i", $courseId);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        $stmt->close();
        return $row['count'];
    }
    
    /**
     * إعادة ترتيب الفيديوهات
     * 
     * @param array $orderData مصفوفة تحتوي على معرفات الفيديوهات وترتيبها الجديد
     * @return bool نجاح أو فشل العملية
     */
    public function reorderVideos($orderData) {
        $success = true;
        
        foreach ($orderData as $videoId => $orderNum) {
            $stmt = $this->db->prepare("UPDATE videos SET order_num = ? WHERE id = ?");
            $stmt->bind_param("ii", $orderNum, $videoId);
            
            if (!$stmt->execute()) {
                $success = false;
            }
            
            $stmt->close();
        }
        
        return $success;
    }
    
    /**
     * استخراج مدة الفيديو باستخدام FFmpeg
     * 
     * @param string $filePath مسار ملف الفيديو
     * @return string|null مدة الفيديو أو null في حالة الفشل
     */
    public function extractVideoDuration($filePath) {
        $fullPath = APP_ROOT . '/' . $filePath;
        
        if (!file_exists($fullPath)) {
            return null;
        }
        
        // التحقق من وجود FFmpeg
        exec('which ffmpeg', $output, $returnVal);
        
        if ($returnVal !== 0) {
            return null; // FFmpeg غير مثبت
        }
        
        // استخراج مدة الفيديو
        $command = "ffmpeg -i \"$fullPath\" 2>&1 | grep 'Duration' | cut -d ' ' -f 4 | sed s/,//";
        exec($command, $output);
        
        if (!empty($output)) {
            $duration = trim($output[0]);
            
            // تحويل الصيغة HH:MM:SS.MS إلى MM:SS
            $parts = explode(':', $duration);
            if (count($parts) === 3) {
                $hours = (int)$parts[0];
                $minutes = (int)$parts[1];
                $seconds = (int)$parts[2];
                
                if ($hours > 0) {
                    return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
                } else {
                    return sprintf('%02d:%02d', $minutes, $seconds);
                }
            }
            
            return $duration;
        }
        
        return null;
    }
}
?>
