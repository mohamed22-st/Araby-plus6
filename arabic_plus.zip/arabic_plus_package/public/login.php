<?php
// تضمين ملف التكوين
require_once '../src/config/config.php';

// التحقق مما إذا كان المستخدم مسجل الدخول بالفعل
if (isLoggedIn()) {
    redirect('index.php');
}

// تضمين نموذج المستخدم
require_once '../src/models/User.php';

// معالجة نموذج تسجيل الدخول
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // الحصول على البيانات وتنظيفها
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']) ? true : false;
    
    // التحقق من الحقول المطلوبة
    if (empty($username) || empty($password)) {
        flashError('يرجى ملء جميع الحقول المطلوبة');
    } else {
        // إنشاء كائن المستخدم
        $user = new User();
        
        // محاولة تسجيل الدخول
        $loggedIn = $user->login($username, $password);
        
        if ($loggedIn) {
            // إعادة التوجيه إلى الصفحة المطلوبة أو الصفحة الرئيسية
            $redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'index.php';
            redirect($redirect);
        } else {
            flashError('اسم المستخدم أو كلمة المرور غير صحيحة');
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - عربي بلس</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Tajawal:wght@400;500;700&display=swap">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- القائمة العلوية -->
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <img src="../assets/images/logo.png" alt="عربي بلس" onerror="this.src='../assets/images/logo-placeholder.png'">
                </a>
                
                <ul class="nav-links">
                    <li><a href="index.php">الرئيسية</a></li>
                    <li><a href="courses.php">الدورات</a></li>
                    <li><a href="subscription.php">الاشتراكات</a></li>
                    <li><a href="about.php">عن المنصة</a></li>
                    <li><a href="contact.php">اتصل بنا</a></li>
                </ul>
                
                <div class="auth-buttons">
                    <a href="login.php" class="btn btn-outline active">تسجيل الدخول</a>
                    <a href="register.php" class="btn btn-primary">إنشاء حساب</a>
                </div>
            </nav>
        </div>
    </header>
    
    <!-- قسم تسجيل الدخول -->
    <section class="section auth-section">
        <div class="container">
            <h2 class="section-title">تسجيل الدخول</h2>
            
            <div class="auth-form">
                <?php displayFlashMessage(); ?>
                
                <form id="login-form" action="login.php<?php echo isset($_GET['redirect']) ? '?redirect=' . $_GET['redirect'] : ''; ?>" method="POST">
                    <div class="form-group">
                        <label for="username">اسم المستخدم</label>
                        <input type="text" id="username" name="username" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">كلمة المرور</label>
                        <input type="password" id="password" name="password" class="form-control" required>
                    </div>
                    
                    <div class="form-group remember-me">
                        <input type="checkbox" id="remember" name="remember">
                        <label for="remember">تذكرني</label>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block">تسجيل الدخول</button>
                    </div>
                    
                    <div class="form-footer">
                        <p>ليس لديك حساب؟ <a href="register.php">إنشاء حساب جديد</a></p>
                        <p><a href="forgot-password.php">نسيت كلمة المرور؟</a></p>
                    </div>
                </form>
            </div>
        </div>
    </section>
    
    <!-- التذييل -->
    <footer>
        <div class="container">
            <ul class="footer-links">
                <li><a href="index.php">الرئيسية</a></li>
                <li><a href="courses.php">الدورات</a></li>
                <li><a href="subscription.php">الاشتراكات</a></li>
                <li><a href="about.php">عن المنصة</a></li>
                <li><a href="contact.php">اتصل بنا</a></li>
                <li><a href="privacy.php">سياسة الخصوصية</a></li>
                <li><a href="terms.php">شروط الاستخدام</a></li>
            </ul>
            
            <div class="copyright">
                &copy; <?php echo date('Y'); ?> عربي بلس - جميع الحقوق محفوظة
            </div>
        </div>
    </footer>
    
    <script src="../assets/js/main.js"></script>
</body>
</html>
