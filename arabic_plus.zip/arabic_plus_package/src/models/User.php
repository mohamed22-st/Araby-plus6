<?php
/**
 * نموذج المستخدم
 * يتعامل مع عمليات المستخدمين مثل التسجيل وتسجيل الدخول وإدارة الحسابات
 */
class User {
    private $db;
    
    /**
     * المُنشئ - يقوم بإنشاء اتصال بقاعدة البيانات
     */
    public function __construct() {
        $this->db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($this->db->connect_error) {
            die("فشل الاتصال بقاعدة البيانات: " . $this->db->connect_error);
        }
    }
    
    /**
     * تسجيل مستخدم جديد
     * 
     * @param string $username اسم المستخدم
     * @param string $password كلمة المرور
     * @param string $email البريد الإلكتروني
     * @param string $fullName الاسم الكامل
     * @param string $role دور المستخدم (افتراضيًا: student)
     * @return bool نجاح أو فشل العملية
     */
    public function register($username, $password, $email, $fullName, $role = 'student') {
        // تشفير كلمة المرور
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // إعداد الاستعلام
        $stmt = $this->db->prepare("INSERT INTO users (username, password, email, full_name, role) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $username, $hashedPassword, $email, $fullName, $role);
        
        // تنفيذ الاستعلام
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    }
    
    /**
     * تسجيل دخول المستخدم
     * 
     * @param string $username اسم المستخدم
     * @param string $password كلمة المرور
     * @return bool نجاح أو فشل العملية
     */
    public function login($username, $password) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT id, username, password, email, full_name, role FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            // الحصول على بيانات المستخدم
            $user = $result->fetch_assoc();
            
            // التحقق من كلمة المرور
            if (password_verify($password, $user['password'])) {
                // تعيين بيانات الجلسة
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['user_role'] = $user['role'];
                
                $stmt->close();
                return true;
            }
        }
        
        $stmt->close();
        return false;
    }
    
    /**
     * تسجيل خروج المستخدم
     */
    public function logout() {
        // حذف متغيرات الجلسة
        unset($_SESSION['user_id']);
        unset($_SESSION['username']);
        unset($_SESSION['email']);
        unset($_SESSION['full_name']);
        unset($_SESSION['user_role']);
        
        // إعادة تعيين الجلسة
        session_destroy();
        
        return true;
    }
    
    /**
     * البحث عن مستخدم باستخدام اسم المستخدم
     * 
     * @param string $username اسم المستخدم
     * @return bool|array بيانات المستخدم أو false إذا لم يتم العثور عليه
     */
    public function findUserByUsername($username) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT id, username, email, full_name, role FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            $stmt->close();
            return $user;
        }
        
        $stmt->close();
        return false;
    }
    
    /**
     * البحث عن مستخدم باستخدام البريد الإلكتروني
     * 
     * @param string $email البريد الإلكتروني
     * @return bool|array بيانات المستخدم أو false إذا لم يتم العثور عليه
     */
    public function findUserByEmail($email) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT id, username, email, full_name, role FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            $stmt->close();
            return $user;
        }
        
        $stmt->close();
        return false;
    }
    
    /**
     * الحصول على بيانات المستخدم باستخدام المعرف
     * 
     * @param int $id معرف المستخدم
     * @return bool|array بيانات المستخدم أو false إذا لم يتم العثور عليه
     */
    public function getUserById($id) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT id, username, email, full_name, role, created_at FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            $stmt->close();
            return $user;
        }
        
        $stmt->close();
        return false;
    }
    
    /**
     * تحديث بيانات المستخدم
     * 
     * @param int $id معرف المستخدم
     * @param array $data البيانات المراد تحديثها
     * @return bool نجاح أو فشل العملية
     */
    public function updateUser($id, $data) {
        // بناء استعلام التحديث
        $query = "UPDATE users SET ";
        $params = [];
        $types = "";
        
        foreach ($data as $key => $value) {
            if ($key !== 'id') {
                $query .= "$key = ?, ";
                $params[] = $value;
                
                // تحديد نوع البيانات
                if (is_int($value)) {
                    $types .= "i";
                } elseif (is_double($value)) {
                    $types .= "d";
                } else {
                    $types .= "s";
                }
            }
        }
        
        // إزالة الفاصلة الأخيرة والمسافة
        $query = rtrim($query, ", ");
        
        // إضافة شرط WHERE
        $query .= " WHERE id = ?";
        $params[] = $id;
        $types .= "i";
        
        // إعداد الاستعلام
        $stmt = $this->db->prepare($query);
        
        // ربط المعلمات
        $stmt->bind_param($types, ...$params);
        
        // تنفيذ الاستعلام
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    }
    
    /**
     * تغيير كلمة المرور
     * 
     * @param int $id معرف المستخدم
     * @param string $newPassword كلمة المرور الجديدة
     * @return bool نجاح أو فشل العملية
     */
    public function changePassword($id, $newPassword) {
        // تشفير كلمة المرور الجديدة
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        
        // إعداد الاستعلام
        $stmt = $this->db->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hashedPassword, $id);
        
        // تنفيذ الاستعلام
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    }
    
    /**
     * الحصول على جميع المستخدمين
     * 
     * @param string $role دور المستخدم (اختياري)
     * @return array قائمة المستخدمين
     */
    public function getAllUsers($role = null) {
        // بناء الاستعلام
        $query = "SELECT id, username, email, full_name, role, created_at FROM users";
        
        if ($role) {
            $query .= " WHERE role = ?";
            $stmt = $this->db->prepare($query);
            $stmt->bind_param("s", $role);
        } else {
            $stmt = $this->db->prepare($query);
        }
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        
        $stmt->close();
        return $users;
    }
    
    /**
     * حذف مستخدم
     * 
     * @param int $id معرف المستخدم
     * @return bool نجاح أو فشل العملية
     */
    public function deleteUser($id) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        // تنفيذ الاستعلام
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    }
    
    /**
     * التحقق من صلاحيات المسؤول
     * 
     * @return bool هل المستخدم مسؤول أم لا
     */
    public function isAdmin() {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    }
    
    /**
     * عدد المستخدمين
     * 
     * @param string $role دور المستخدم (اختياري)
     * @return int عدد المستخدمين
     */
    public function countUsers($role = null) {
        // بناء الاستعلام
        $query = "SELECT COUNT(*) as count FROM users";
        
        if ($role) {
            $query .= " WHERE role = ?";
            $stmt = $this->db->prepare($query);
            $stmt->bind_param("s", $role);
        } else {
            $stmt = $this->db->prepare($query);
        }
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        $stmt->close();
        return $row['count'];
    }
    
    /**
     * المستخدمين الجدد في الفترة الأخيرة
     * 
     * @param int $days عدد الأيام
     * @return int عدد المستخدمين الجدد
     */
    public function getNewUsersCount($days = 30) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)");
        $stmt->bind_param("i", $days);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        $stmt->close();
        return $row['count'];
    }
}
?>
