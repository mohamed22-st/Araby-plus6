<?php
// تضمين ملف التكوين
require_once '../src/config/config.php';

// التحقق من وجود معرف الفيديو
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    redirect('courses.php');
}

$videoId = (int)$_GET['id'];

// تضمين النماذج المطلوبة
require_once '../src/models/Video.php';
require_once '../src/models/Course.php';
require_once '../src/models/Subscription.php';

// إنشاء كائنات النماذج
$videoModel = new Video();
$courseModel = new Course();
$subscriptionModel = new Subscription();

// الحصول على بيانات الفيديو
$video = $videoModel->getVideoById($videoId);

// التحقق من وجود الفيديو
if (!$video) {
    flashError('الفيديو غير موجود');
    redirect('courses.php');
}

// الحصول على بيانات الدورة
$course = $courseModel->getCourseById($video['course_id']);

// التحقق من صلاحية الاشتراك للوصول إلى المحتوى
$hasAccess = isLoggedIn() && hasValidSubscription();

// إذا لم يكن المستخدم مسجل الدخول أو ليس لديه اشتراك صالح
if (!$hasAccess) {
    if (!isLoggedIn()) {
        flashError('يرجى تسجيل الدخول لمشاهدة هذا الفيديو');
        redirect('login.php?redirect=video.php?id=' . $videoId);
    } else {
        flashError('يرجى الاشتراك لمشاهدة هذا الفيديو');
        redirect('subscription.php');
    }
}

// الحصول على قائمة فيديوهات الدورة
$courseVideos = $videoModel->getVideosByCourse($video['course_id']);

// تحديد الفيديو السابق والتالي
$prevVideo = null;
$nextVideo = null;
$currentIndex = 0;

foreach ($courseVideos as $index => $v) {
    if ($v['id'] == $videoId) {
        $currentIndex = $index;
        break;
    }
}

if ($currentIndex > 0) {
    $prevVideo = $courseVideos[$currentIndex - 1];
}

if ($currentIndex < count($courseVideos) - 1) {
    $nextVideo = $courseVideos[$currentIndex + 1];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $video['title']; ?> - عربي بلس</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Tajawal:wght@400;500;700&display=swap">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- القائمة العلوية -->
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <img src="../assets/images/logo.png" alt="عربي بلس" onerror="this.src='../assets/images/logo-placeholder.png'">
                </a>
                
                <ul class="nav-links">
                    <li><a href="index.php">الرئيسية</a></li>
                    <li><a href="courses.php" class="active">الدورات</a></li>
                    <li><a href="subscription.php">الاشتراكات</a></li>
                    <li><a href="about.php">عن المنصة</a></li>
                    <li><a href="contact.php">اتصل بنا</a></li>
                </ul>
                
                <div class="auth-buttons">
                    <?php if (isLoggedIn()): ?>
                        <a href="dashboard.php" class="btn btn-outline">لوحة التحكم</a>
                        <a href="logout.php" class="btn btn-primary">تسجيل الخروج</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-outline">تسجيل الدخول</a>
                        <a href="register.php" class="btn btn-primary">إنشاء حساب</a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>
    
    <!-- عرض الفيديو -->
    <section class="section video-section">
        <div class="container">
            <?php displayFlashMessage(); ?>
            
            <div class="course-navigation">
                <a href="course-details.php?id=<?php echo $course['id']; ?>" class="btn btn-outline">
                    <span class="icon">←</span>
                    <span class="text">العودة إلى الدورة</span>
                </a>
                
                <div class="course-info">
                    <h2 class="course-title"><?php echo $course['title']; ?></h2>
                    <div class="course-meta">
                        <span class="course-grade"><?php echo $course['grade']; ?></span>
                        <span class="course-type"><?php echo $course['type'] === 'azhar' ? 'الأزهر' : 'التعليم العام'; ?></span>
                    </div>
                </div>
            </div>
            
            <div class="video-player-container">
                <div class="video-container">
                    <video id="video-player" controls>
                        <source src="../<?php echo $video['file_path']; ?>" type="video/mp4">
                        متصفحك لا يدعم تشغيل الفيديو.
                    </video>
                </div>
                
                <div class="video-info">
                    <h1 class="video-title"><?php echo $video['title']; ?></h1>
                    
                    <div class="video-meta">
                        <?php if ($video['duration']): ?>
                            <span class="video-duration">المدة: <?php echo $video['duration']; ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($video['description']): ?>
                        <div class="video-description">
                            <p><?php echo nl2br($video['description']); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="video-navigation">
                <?php if ($prevVideo): ?>
                    <a href="video.php?id=<?php echo $prevVideo['id']; ?>" class="btn btn-outline prev-video">
                        <span class="icon">←</span>
                        <span class="text">الفيديو السابق</span>
                    </a>
                <?php else: ?>
                    <button class="btn btn-outline prev-video" disabled>
                        <span class="icon">←</span>
                        <span class="text">الفيديو السابق</span>
                    </button>
                <?php endif; ?>
                
                <?php if ($nextVideo): ?>
                    <a href="video.php?id=<?php echo $nextVideo['id']; ?>" class="btn btn-primary next-video">
                        <span class="text">الفيديو التالي</span>
                        <span class="icon">→</span>
                    </a>
                <?php else: ?>
                    <button class="btn btn-primary next-video" disabled>
                        <span class="text">الفيديو التالي</span>
                        <span class="icon">→</span>
                    </button>
                <?php endif; ?>
            </div>
            
            <div class="course-videos">
                <h2>فيديوهات الدورة</h2>
                
                <div class="videos-list">
                    <?php foreach ($courseVideos as $index => $v): ?>
                        <div class="video-item <?php echo $v['id'] == $videoId ? 'active' : ''; ?>">
                            <div class="video-info">
                                <span class="video-number"><?php echo $index + 1; ?></span>
                                <h3 class="video-title"><?php echo $v['title']; ?></h3>
                                <?php if ($v['duration']): ?>
                                    <span class="video-duration"><?php echo $v['duration']; ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <a href="video.php?id=<?php echo $v['id']; ?>" class="btn btn-sm <?php echo $v['id'] == $videoId ? 'btn-primary' : 'btn-outline'; ?>">
                                <?php echo $v['id'] == $videoId ? 'قيد المشاهدة' : 'مشاهدة'; ?>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>
    
    <!-- التذييل -->
    <footer>
        <div class="container">
            <ul class="footer-links">
                <li><a href="index.php">الرئيسية</a></li>
                <li><a href="courses.php">الدورات</a></li>
                <li><a href="subscription.php">الاشتراكات</a></li>
                <li><a href="about.php">عن المنصة</a></li>
                <li><a href="contact.php">اتصل بنا</a></li>
                <li><a href="privacy.php">سياسة الخصوصية</a></li>
                <li><a href="terms.php">شروط الاستخدام</a></li>
            </ul>
            
            <div class="copyright">
                &copy; <?php echo date('Y'); ?> عربي بلس - جميع الحقوق محفوظة
            </div>
        </div>
    </footer>
    
    <script src="../assets/js/main.js"></script>
</body>
</html>
