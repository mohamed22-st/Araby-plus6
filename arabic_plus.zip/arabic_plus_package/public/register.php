<?php
// تضمين ملف التكوين
require_once '../src/config/config.php';

// التحقق مما إذا كان المستخدم مسجل الدخول بالفعل
if (isLoggedIn()) {
    redirect('index.php');
}

// تضمين نموذج المستخدم
require_once '../src/models/User.php';

// معالجة نموذج التسجيل
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // الحصول على البيانات وتنظيفها
    $fullName = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];
    
    // التحقق من الحقول المطلوبة
    if (empty($fullName) || empty($email) || empty($username) || empty($password) || empty($confirmPassword)) {
        flashError('يرجى ملء جميع الحقول المطلوبة');
    } elseif ($password !== $confirmPassword) {
        flashError('كلمات المرور غير متطابقة');
    } elseif (strlen($password) < 6) {
        flashError('يجب أن تتكون كلمة المرور من 6 أحرف على الأقل');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flashError('يرجى إدخال بريد إلكتروني صحيح');
    } else {
        // إنشاء كائن المستخدم
        $user = new User();
        
        // التحقق من وجود اسم المستخدم أو البريد الإلكتروني
        if ($user->findUserByUsername($username)) {
            flashError('اسم المستخدم موجود بالفعل');
        } elseif ($user->findUserByEmail($email)) {
            flashError('البريد الإلكتروني موجود بالفعل');
        } else {
            // محاولة تسجيل المستخدم
            $registered = $user->register($username, $password, $email, $fullName);
            
            if ($registered) {
                flashSuccess('تم إنشاء الحساب بنجاح. يمكنك الآن تسجيل الدخول');
                redirect('login.php');
            } else {
                flashError('حدث خطأ أثناء إنشاء الحساب. يرجى المحاولة مرة أخرى');
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إنشاء حساب - عربي بلس</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Tajawal:wght@400;500;700&display=swap">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- القائمة العلوية -->
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <img src="../assets/images/logo.png" alt="عربي بلس" onerror="this.src='../assets/images/logo-placeholder.png'">
                </a>
                
                <ul class="nav-links">
                    <li><a href="index.php">الرئيسية</a></li>
                    <li><a href="courses.php">الدورات</a></li>
                    <li><a href="subscription.php">الاشتراكات</a></li>
                    <li><a href="about.php">عن المنصة</a></li>
                    <li><a href="contact.php">اتصل بنا</a></li>
                </ul>
                
                <div class="auth-buttons">
                    <a href="login.php" class="btn btn-outline">تسجيل الدخول</a>
                    <a href="register.php" class="btn btn-primary active">إنشاء حساب</a>
                </div>
            </nav>
        </div>
    </header>
    
    <!-- قسم التسجيل -->
    <section class="section auth-section">
        <div class="container">
            <h2 class="section-title">إنشاء حساب جديد</h2>
            
            <div class="auth-form">
                <?php displayFlashMessage(); ?>
                
                <form id="register-form" action="register.php" method="POST">
                    <div class="form-group">
                        <label for="full-name">الاسم الكامل</label>
                        <input type="text" id="full-name" name="full_name" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">البريد الإلكتروني</label>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="username">اسم المستخدم</label>
                        <input type="text" id="username" name="username" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">كلمة المرور</label>
                        <input type="password" id="password" name="password" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm-password">تأكيد كلمة المرور</label>
                        <input type="password" id="confirm-password" name="confirm_password" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block">إنشاء حساب</button>
                    </div>
                    
                    <div class="form-footer">
                        <p>لديك حساب بالفعل؟ <a href="login.php">تسجيل الدخول</a></p>
                    </div>
                </form>
            </div>
        </div>
    </section>
    
    <!-- التذييل -->
    <footer>
        <div class="container">
            <ul class="footer-links">
                <li><a href="index.php">الرئيسية</a></li>
                <li><a href="courses.php">الدورات</a></li>
                <li><a href="subscription.php">الاشتراكات</a></li>
                <li><a href="about.php">عن المنصة</a></li>
                <li><a href="contact.php">اتصل بنا</a></li>
                <li><a href="privacy.php">سياسة الخصوصية</a></li>
                <li><a href="terms.php">شروط الاستخدام</a></li>
            </ul>
            
            <div class="copyright">
                &copy; <?php echo date('Y'); ?> عربي بلس - جميع الحقوق محفوظة
            </div>
        </div>
    </footer>
    
    <script src="../assets/js/main.js"></script>
</body>
</html>
