<?php
// تضمين ملف التكوين
require_once '../src/config/config.php';

// التحقق من تسجيل الدخول
if (!isLoggedIn()) {
    flashError('يرجى تسجيل الدخول للاشتراك في المنصة');
    redirect('login.php?redirect=subscription.php');
}

// التحقق من وجود نوع الخطة
if (!isset($_GET['plan']) || !in_array($_GET['plan'], ['monthly', 'quarterly', 'yearly'])) {
    flashError('خطة الاشتراك غير صالحة');
    redirect('subscription.php');
}

// تضمين النماذج المطلوبة
require_once '../src/models/Subscription.php';

// تحديد نوع الخطة المختارة
$selectedPlan = $_GET['plan'];

// تعريف خطط الاشتراك
$plans = [
    'monthly' => [
        'name' => 'الاشتراك الشهري',
        'price' => 100,
        'duration' => 'شهر',
        'type' => 'monthly'
    ],
    'quarterly' => [
        'name' => 'الاشتراك الربع سنوي',
        'price' => 250,
        'duration' => '3 أشهر',
        'type' => 'quarterly'
    ],
    'yearly' => [
        'name' => 'الاشتراك السنوي',
        'price' => 900,
        'duration' => 'سنة',
        'type' => 'yearly'
    ]
];

// التحقق من وجود الخطة المختارة
if (!array_key_exists($selectedPlan, $plans)) {
    flashError('خطة الاشتراك غير صالحة');
    redirect('subscription.php');
}

// الحصول على معلومات الخطة المختارة
$plan = $plans[$selectedPlan];

// معالجة نموذج الدفع
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // الحصول على البيانات وتنظيفها
    $phoneNumber = sanitize($_POST['phone_number']);
    $transactionId = sanitize($_POST['transaction_id']);
    
    // التحقق من الحقول المطلوبة
    if (empty($phoneNumber) || empty($transactionId)) {
        flashError('يرجى ملء جميع الحقول المطلوبة');
    } else {
        // التحقق من صحة رقم الهاتف
        if (!preg_match('/^01[0-2]\d{8}$/', $phoneNumber)) {
            flashError('رقم الهاتف غير صالح. يجب أن يكون رقم فودافون مصري (11 رقم)');
        } else {
            // إنشاء كائن الاشتراك
            $subscriptionModel = new Subscription();
            
            // إنشاء اشتراك جديد
            $subscriptionId = $subscriptionModel->createSubscription(
                $_SESSION['user_id'],
                $plan['type'],
                $plan['price'],
                'فودافون كاش',
                $transactionId
            );
            
            if ($subscriptionId) {
                flashSuccess('تم الاشتراك بنجاح. يمكنك الآن الاستمتاع بجميع مزايا المنصة');
                redirect('courses.php');
            } else {
                flashError('حدث خطأ أثناء معالجة الاشتراك. يرجى المحاولة مرة أخرى');
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الدفع - عربي بلس</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Tajawal:wght@400;500;700&display=swap">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- القائمة العلوية -->
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <img src="../assets/images/logo.png" alt="عربي بلس" onerror="this.src='../assets/images/logo-placeholder.png'">
                </a>
                
                <ul class="nav-links">
                    <li><a href="index.php">الرئيسية</a></li>
                    <li><a href="courses.php">الدورات</a></li>
                    <li><a href="subscription.php" class="active">الاشتراكات</a></li>
                    <li><a href="about.php">عن المنصة</a></li>
                    <li><a href="contact.php">اتصل بنا</a></li>
                </ul>
                
                <div class="auth-buttons">
                    <a href="dashboard.php" class="btn btn-outline">لوحة التحكم</a>
                    <a href="logout.php" class="btn btn-primary">تسجيل الخروج</a>
                </div>
            </nav>
        </div>
    </header>
    
    <!-- قسم الدفع -->
    <section class="section payment-section">
        <div class="container">
            <h1 class="section-title">إتمام عملية الدفع</h1>
            
            <?php displayFlashMessage(); ?>
            
            <div class="payment-details">
                <h2>تفاصيل الاشتراك</h2>
                <div class="plan-summary">
                    <div class="plan-info">
                        <p><strong>نوع الاشتراك:</strong> <?php echo $plan['name']; ?></p>
                        <p><strong>المدة:</strong> <?php echo $plan['duration']; ?></p>
                        <p><strong>المبلغ:</strong> <?php echo $plan['price']; ?> جنيه</p>
                    </div>
                </div>
            </div>
            
            <div class="payment-methods-section">
                <h2>طريقة الدفع</h2>
                <div class="payment-method active">
                    <div class="payment-method-header">
                        <img src="../assets/images/payment/vodafone-cash.png" alt="فودافون كاش" onerror="this.src='../assets/images/payment-placeholder.png'">
                        <span>فودافون كاش</span>
                    </div>
                </div>
            </div>
            
            <div class="payment-instructions">
                <h2>تعليمات الدفع</h2>
                <ol>
                    <li>قم بتحويل مبلغ <strong><?php echo $plan['price']; ?> جنيه</strong> إلى رقم فودافون كاش <strong>01012345678</strong></li>
                    <li>احتفظ برقم العملية الذي ستحصل عليه بعد إتمام التحويل</li>
                    <li>أدخل رقم هاتفك ورقم العملية في النموذج أدناه</li>
                    <li>انقر على زر "تأكيد الدفع" لإتمام عملية الاشتراك</li>
                </ol>
            </div>
            
            <div class="payment-form">
                <h2>تأكيد الدفع</h2>
                <form action="payment.php?plan=<?php echo $selectedPlan; ?>" method="POST">
                    <div class="form-group">
                        <label for="phone_number">رقم الهاتف (فودافون)</label>
                        <input type="text" id="phone_number" name="phone_number" class="form-control" placeholder="مثال: 01012345678" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="transaction_id">رقم العملية</label>
                        <input type="text" id="transaction_id" name="transaction_id" class="form-control" placeholder="أدخل رقم العملية الذي حصلت عليه بعد التحويل" required>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block">تأكيد الدفع</button>
                    </div>
                </form>
            </div>
            
            <div class="payment-note">
                <p>ملاحظة: سيتم التحقق من عملية الدفع وتفعيل الاشتراك خلال 24 ساعة. في حالة وجود أي مشكلة، يرجى التواصل مع الدعم الفني.</p>
            </div>
        </div>
    </section>
    
    <!-- التذييل -->
    <footer>
        <div class="container">
            <ul class="footer-links">
                <li><a href="index.php">الرئيسية</a></li>
                <li><a href="courses.php">الدورات</a></li>
                <li><a href="subscription.php">الاشتراكات</a></li>
                <li><a href="about.php">عن المنصة</a></li>
                <li><a href="contact.php">اتصل بنا</a></li>
                <li><a href="privacy.php">سياسة الخصوصية</a></li>
                <li><a href="terms.php">شروط الاستخدام</a></li>
            </ul>
            
            <div class="copyright">
                &copy; <?php echo date('Y'); ?> عربي بلس - جميع الحقوق محفوظة
            </div>
        </div>
    </footer>
    
    <script src="../assets/js/main.js"></script>
</body>
</html>
