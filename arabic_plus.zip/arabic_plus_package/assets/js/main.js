// ملف JavaScript الرئيسي لمنصة عربي بلس

document.addEventListener('DOMContentLoaded', function() {
    // تهيئة عناصر الصفحة
    initializeComponents();
    
    // إضافة مستمعي الأحداث
    setupEventListeners();
});

/**
 * تهيئة مكونات الصفحة
 */
function initializeComponents() {
    // تهيئة القائمة المتنقلة للشاشات الصغيرة
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    if (mobileMenuButton) {
        const navLinks = document.querySelector('.nav-links');
        
        mobileMenuButton.addEventListener('click', function() {
            navLinks.classList.toggle('active');
        });
    }
    
    // تهيئة رسائل التنبيه
    setupAlerts();
}

/**
 * إعداد مستمعي الأحداث
 */
function setupEventListeners() {
    // مستمعي أحداث نماذج التسجيل وتسجيل الدخول
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            if (!validateLoginForm()) {
                e.preventDefault();
            }
        });
    }
    
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            if (!validateRegisterForm()) {
                e.preventDefault();
            }
        });
    }
    
    // مستمعي أحداث نظام الاشتراك
    const subscriptionButtons = document.querySelectorAll('.subscribe-btn');
    subscriptionButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const planId = this.getAttribute('data-plan-id');
            handleSubscription(planId);
        });
    });
}

/**
 * التحقق من صحة نموذج تسجيل الدخول
 */
function validateLoginForm() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    let isValid = true;
    
    // التحقق من اسم المستخدم
    if (username.trim() === '') {
        showError('username', 'يرجى إدخال اسم المستخدم');
        isValid = false;
    } else {
        clearError('username');
    }
    
    // التحقق من كلمة المرور
    if (password.trim() === '') {
        showError('password', 'يرجى إدخال كلمة المرور');
        isValid = false;
    } else {
        clearError('password');
    }
    
    return isValid;
}

/**
 * التحقق من صحة نموذج التسجيل
 */
function validateRegisterForm() {
    const fullName = document.getElementById('full-name').value;
    const email = document.getElementById('email').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    let isValid = true;
    
    // التحقق من الاسم الكامل
    if (fullName.trim() === '') {
        showError('full-name', 'يرجى إدخال الاسم الكامل');
        isValid = false;
    } else {
        clearError('full-name');
    }
    
    // التحقق من البريد الإلكتروني
    if (email.trim() === '') {
        showError('email', 'يرجى إدخال البريد الإلكتروني');
        isValid = false;
    } else if (!isValidEmail(email)) {
        showError('email', 'يرجى إدخال بريد إلكتروني صحيح');
        isValid = false;
    } else {
        clearError('email');
    }
    
    // التحقق من اسم المستخدم
    if (username.trim() === '') {
        showError('username', 'يرجى إدخال اسم المستخدم');
        isValid = false;
    } else {
        clearError('username');
    }
    
    // التحقق من كلمة المرور
    if (password.trim() === '') {
        showError('password', 'يرجى إدخال كلمة المرور');
        isValid = false;
    } else if (password.length < 6) {
        showError('password', 'يجب أن تتكون كلمة المرور من 6 أحرف على الأقل');
        isValid = false;
    } else {
        clearError('password');
    }
    
    // التحقق من تأكيد كلمة المرور
    if (confirmPassword.trim() === '') {
        showError('confirm-password', 'يرجى تأكيد كلمة المرور');
        isValid = false;
    } else if (confirmPassword !== password) {
        showError('confirm-password', 'كلمات المرور غير متطابقة');
        isValid = false;
    } else {
        clearError('confirm-password');
    }
    
    return isValid;
}

/**
 * التحقق من صحة البريد الإلكتروني
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * عرض رسالة خطأ لحقل معين
 */
function showError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(`${fieldId}-error`);
    
    field.classList.add('error');
    
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    } else {
        const newErrorElement = document.createElement('div');
        newErrorElement.id = `${fieldId}-error`;
        newErrorElement.className = 'error-message';
        newErrorElement.textContent = message;
        
        field.parentNode.appendChild(newErrorElement);
    }
}

/**
 * إزالة رسالة الخطأ من حقل معين
 */
function clearError(fieldId) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(`${fieldId}-error`);
    
    field.classList.remove('error');
    
    if (errorElement) {
        errorElement.textContent = '';
        errorElement.style.display = 'none';
    }
}

/**
 * إعداد رسائل التنبيه
 */
function setupAlerts() {
    const alerts = document.querySelectorAll('.alert');
    
    alerts.forEach(alert => {
        // إضافة زر إغلاق لكل تنبيه
        const closeButton = document.createElement('span');
        closeButton.className = 'alert-close';
        closeButton.innerHTML = '&times;';
        closeButton.addEventListener('click', function() {
            alert.style.display = 'none';
        });
        
        alert.appendChild(closeButton);
        
        // إخفاء التنبيه تلقائيًا بعد 5 ثوانٍ
        setTimeout(function() {
            alert.style.display = 'none';
        }, 5000);
    });
}

/**
 * معالجة عملية الاشتراك
 */
function handleSubscription(planId) {
    // التحقق من تسجيل الدخول
    if (!isLoggedIn()) {
        // توجيه المستخدم إلى صفحة تسجيل الدخول مع تخزين خطة الاشتراك
        localStorage.setItem('selectedPlan', planId);
        window.location.href = 'login.php?redirect=subscription';
        return;
    }
    
    // توجيه المستخدم إلى صفحة الدفع
    window.location.href = `payment.php?plan=${planId}`;
}

/**
 * التحقق من تسجيل دخول المستخدم
 */
function isLoggedIn() {
    // يمكن التحقق من وجود عنصر معين في الصفحة يظهر فقط للمستخدمين المسجلين
    return document.querySelector('.user-menu') !== null;
}

/**
 * تحميل محتوى الفيديو
 */
function loadVideo(videoId) {
    const videoContainer = document.getElementById('video-container');
    
    if (videoContainer) {
        // عرض مؤشر التحميل
        videoContainer.innerHTML = '<div class="loading">جاري تحميل الفيديو...</div>';
        
        // محاكاة طلب AJAX لتحميل الفيديو
        setTimeout(function() {
            // استبدال بكود لتحميل الفيديو الفعلي من الخادم
            videoContainer.innerHTML = `
                <iframe src="videos/${videoId}.mp4" 
                        frameborder="0" 
                        allowfullscreen>
                </iframe>
            `;
        }, 1000);
    }
}

/**
 * وظائف لوحة التحكم
 */
// تبديل حالة القائمة الجانبية
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const adminContent = document.querySelector('.admin-content');
    
    sidebar.classList.toggle('collapsed');
    adminContent.classList.toggle('expanded');
}

// تحميل محتوى لوحة التحكم بشكل غير متزامن
function loadAdminContent(section) {
    const contentArea = document.getElementById('admin-content-area');
    
    if (contentArea) {
        // عرض مؤشر التحميل
        contentArea.innerHTML = '<div class="loading">جاري تحميل المحتوى...</div>';
        
        // محاكاة طلب AJAX لتحميل المحتوى
        fetch(`admin/sections/${section}.php`)
            .then(response => response.text())
            .then(html => {
                contentArea.innerHTML = html;
                // تهيئة المكونات الجديدة
                initializeAdminComponents();
            })
            .catch(error => {
                contentArea.innerHTML = '<div class="error">حدث خطأ أثناء تحميل المحتوى</div>';
                console.error('Error loading admin content:', error);
            });
    }
}

// تهيئة مكونات لوحة التحكم
function initializeAdminComponents() {
    // تهيئة محرر النصوص الغني إذا كان موجودًا
    const richTextEditors = document.querySelectorAll('.rich-text-editor');
    if (richTextEditors.length > 0) {
        richTextEditors.forEach(editor => {
            // يمكن استخدام مكتبة محرر نصوص غني هنا
            console.log('Rich text editor initialized');
        });
    }
    
    // تهيئة مكون رفع الملفات
    const fileUploaders = document.querySelectorAll('.file-uploader');
    if (fileUploaders.length > 0) {
        fileUploaders.forEach(uploader => {
            uploader.addEventListener('change', function(e) {
                const fileName = e.target.files[0].name;
                const fileNameDisplay = uploader.nextElementSibling;
                if (fileNameDisplay) {
                    fileNameDisplay.textContent = fileName;
                }
            });
        });
    }
}

// حذف عنصر من لوحة التحكم
function deleteItem(itemId, itemType) {
    if (confirm(`هل أنت متأكد من رغبتك في حذف هذا العنصر؟`)) {
        // محاكاة طلب AJAX لحذف العنصر
        fetch(`admin/actions/delete.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `id=${itemId}&type=${itemType}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // إزالة العنصر من واجهة المستخدم
                const itemElement = document.getElementById(`${itemType}-${itemId}`);
                if (itemElement) {
                    itemElement.remove();
                }
                showAdminAlert('تم حذف العنصر بنجاح', 'success');
            } else {
                showAdminAlert('حدث خطأ أثناء حذف العنصر', 'error');
            }
        })
        .catch(error => {
            showAdminAlert('حدث خطأ أثناء الاتصال بالخادم', 'error');
            console.error('Error deleting item:', error);
        });
    }
}

// عرض تنبيه في لوحة التحكم
function showAdminAlert(message, type) {
    const alertsContainer = document.getElementById('admin-alerts');
    if (alertsContainer) {
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.textContent = message;
        
        // إضافة زر إغلاق
        const closeButton = document.createElement('span');
        closeButton.className = 'alert-close';
        closeButton.innerHTML = '&times;';
        closeButton.addEventListener('click', function() {
            alert.remove();
        });
        
        alert.appendChild(closeButton);
        alertsContainer.appendChild(alert);
        
        // إزالة التنبيه تلقائيًا بعد 5 ثوانٍ
        setTimeout(function() {
            alert.remove();
        }, 5000);
    }
}
