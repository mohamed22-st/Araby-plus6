<?php
// تضمين ملف التكوين
require_once '../src/config/config.php';

// التحقق مما إذا كان المستخدم مسجل الدخول
if (!isLoggedIn()) {
    redirect('login.php');
}

// تضمين نموذج المستخدم
require_once '../src/models/User.php';

// إنشاء كائن المستخدم
$user = new User();

// تسجيل خروج المستخدم
$user->logout();

// توجيه المستخدم إلى صفحة تسجيل الدخول
flashSuccess('تم تسجيل الخروج بنجاح');
redirect('login.php');
?>
