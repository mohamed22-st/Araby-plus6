<?php
// تضمين ملف التكوين
require_once '../src/config/config.php';

// تضمين النماذج المطلوبة
require_once '../src/models/Course.php';
require_once '../src/models/Video.php';

// الحصول على قائمة الدورات
$courseModel = new Course();
$courses = $courseModel->getAllCourses();

// تحديد نوع الدورة والصف الدراسي للتصفية
$type = isset($_GET['type']) ? $_GET['type'] : null;
$grade = isset($_GET['grade']) ? $_GET['grade'] : null;

// تطبيق التصفية إذا تم تحديدها
if ($type || $grade) {
    $courses = $courseModel->getAllCourses($type, $grade);
}

// الحصول على قائمة الصفوف الدراسية للتصفية
$grades = [
    'الصف الأول الإعدادي',
    'الصف الثاني الإعدادي',
    'الصف الثالث الإعدادي',
    'الصف الأول الثانوي',
    'الصف الثاني الثانوي',
    'الصف الثالث الثانوي'
];
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الدورات - عربي بلس</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Tajawal:wght@400;500;700&display=swap">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- القائمة العلوية -->
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <img src="../assets/images/logo.png" alt="عربي بلس" onerror="this.src='../assets/images/logo-placeholder.png'">
                </a>
                
                <ul class="nav-links">
                    <li><a href="index.php">الرئيسية</a></li>
                    <li><a href="courses.php" class="active">الدورات</a></li>
                    <li><a href="subscription.php">الاشتراكات</a></li>
                    <li><a href="about.php">عن المنصة</a></li>
                    <li><a href="contact.php">اتصل بنا</a></li>
                </ul>
                
                <div class="auth-buttons">
                    <?php if (isLoggedIn()): ?>
                        <a href="dashboard.php" class="btn btn-outline">لوحة التحكم</a>
                        <a href="logout.php" class="btn btn-primary">تسجيل الخروج</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-outline">تسجيل الدخول</a>
                        <a href="register.php" class="btn btn-primary">إنشاء حساب</a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>
    
    <!-- قسم الدورات -->
    <section class="section courses-section">
        <div class="container">
            <h1 class="section-title">استكشف الدورات</h1>
            
            <!-- أدوات التصفية -->
            <div class="filter-tools">
                <div class="filter-group">
                    <label for="grade-filter">الصف الدراسي:</label>
                    <select id="grade-filter" class="form-control" onchange="applyFilter()">
                        <option value="">جميع الصفوف</option>
                        <optgroup label="المرحلة الإعدادية">
                            <?php foreach ($grades as $g): ?>
                                <?php if (strpos($g, 'الإعدادي') !== false): ?>
                                    <option value="<?php echo $g; ?>" <?php echo $grade === $g ? 'selected' : ''; ?>><?php echo $g; ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </optgroup>
                        <optgroup label="المرحلة الثانوية">
                            <?php foreach ($grades as $g): ?>
                                <?php if (strpos($g, 'الثانوي') !== false): ?>
                                    <option value="<?php echo $g; ?>" <?php echo $grade === $g ? 'selected' : ''; ?>><?php echo $g; ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </optgroup>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="type-filter">نوع الدورة:</label>
                    <select id="type-filter" class="form-control" onchange="applyFilter()">
                        <option value="">جميع الأنواع</option>
                        <option value="general" <?php echo $type === 'general' ? 'selected' : ''; ?>>التعليم العام</option>
                        <option value="azhar" <?php echo $type === 'azhar' ? 'selected' : ''; ?>>الأزهر</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <button id="reset-filter" class="btn btn-outline" onclick="resetFilter()">إعادة ضبط</button>
                </div>
            </div>
            
            <!-- عرض الدورات -->
            <div class="courses-grid">
                <?php if (empty($courses)): ?>
                    <p class="no-courses">لا توجد دورات متاحة حاليًا</p>
                <?php else: ?>
                    <?php foreach ($courses as $course): ?>
                        <div class="course-card">
                            <img src="<?php echo $course['thumbnail'] ? '../' . $course['thumbnail'] : '../assets/images/course-placeholder.jpg'; ?>" alt="<?php echo $course['title']; ?>" class="course-image">
                            <div class="course-content">
                                <h3 class="course-title"><?php echo $course['title']; ?></h3>
                                <p class="course-description"><?php echo truncateText($course['description'], 100); ?></p>
                                <div class="course-meta">
                                    <span><?php echo $course['grade']; ?></span>
                                    <span><?php echo $course['type'] === 'azhar' ? 'الأزهر' : 'التعليم العام'; ?></span>
                                </div>
                                <a href="course-details.php?id=<?php echo $course['id']; ?>" class="btn btn-primary">عرض التفاصيل</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    
    <!-- التذييل -->
    <footer>
        <div class="container">
            <ul class="footer-links">
                <li><a href="index.php">الرئيسية</a></li>
                <li><a href="courses.php">الدورات</a></li>
                <li><a href="subscription.php">الاشتراكات</a></li>
                <li><a href="about.php">عن المنصة</a></li>
                <li><a href="contact.php">اتصل بنا</a></li>
                <li><a href="privacy.php">سياسة الخصوصية</a></li>
                <li><a href="terms.php">شروط الاستخدام</a></li>
            </ul>
            
            <div class="copyright">
                &copy; <?php echo date('Y'); ?> عربي بلس - جميع الحقوق محفوظة
            </div>
        </div>
    </footer>
    
    <script>
        // تطبيق التصفية
        function applyFilter() {
            const gradeFilter = document.getElementById('grade-filter').value;
            const typeFilter = document.getElementById('type-filter').value;
            
            let url = 'courses.php';
            const params = [];
            
            if (gradeFilter) {
                params.push(`grade=${encodeURIComponent(gradeFilter)}`);
            }
            
            if (typeFilter) {
                params.push(`type=${encodeURIComponent(typeFilter)}`);
            }
            
            if (params.length > 0) {
                url += '?' + params.join('&');
            }
            
            window.location.href = url;
        }
        
        // إعادة ضبط التصفية
        function resetFilter() {
            window.location.href = 'courses.php';
        }
    </script>
    
    <script src="../assets/js/main.js"></script>
</body>
</html>
