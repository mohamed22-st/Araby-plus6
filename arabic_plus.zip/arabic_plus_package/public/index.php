<?php
// تضمين ملف التكوين
require_once '../src/config/config.php';

// تضمين ملفات النماذج المطلوبة
require_once '../src/models/User.php';
require_once '../src/models/Course.php';

// الحصول على الدورات المميزة
$courseModel = new Course();
$featuredCourses = $courseModel->getFeaturedCourses();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>عربي بلس - منصة تعليم اللغة العربية</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Tajawal:wght@400;500;700&display=swap">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- القائمة العلوية -->
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <img src="../assets/images/logo.png" alt="عربي بلس" onerror="this.src='../assets/images/logo-placeholder.png'">
                </a>
                
                <ul class="nav-links">
                    <li><a href="index.php">الرئيسية</a></li>
                    <li><a href="courses.php">الدورات</a></li>
                    <li><a href="subscription.php">الاشتراكات</a></li>
                    <li><a href="about.php">عن المنصة</a></li>
                    <li><a href="contact.php">اتصل بنا</a></li>
                </ul>
                
                <div class="auth-buttons">
                    <?php if (isLoggedIn()): ?>
                        <a href="dashboard.php" class="btn btn-outline">لوحة التحكم</a>
                        <a href="logout.php" class="btn btn-primary">تسجيل الخروج</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-outline">تسجيل الدخول</a>
                        <a href="register.php" class="btn btn-primary">إنشاء حساب</a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>
    
    <!-- القسم الرئيسي -->
    <section class="hero">
        <div class="container">
            <h1>تعلم اللغة العربية بطريقة مبتكرة</h1>
            <p>منصة عربي بلس توفر لك أفضل الدورات التعليمية في اللغة العربية للمراحل الإعدادية والثانوية بنظامي الأزهر والتعليم العام</p>
            <a href="courses.php" class="btn btn-primary">استكشف الدورات</a>
        </div>
    </section>
    
    <!-- قسم الدورات المميزة -->
    <section class="section">
        <div class="container">
            <h2 class="section-title">الدورات المميزة</h2>
            
            <div class="courses-grid">
                <?php if (empty($featuredCourses)): ?>
                    <p class="no-courses">لا توجد دورات متاحة حاليًا</p>
                <?php else: ?>
                    <?php foreach ($featuredCourses as $course): ?>
                        <div class="course-card">
                            <img src="<?php echo $course['thumbnail'] ? '../' . $course['thumbnail'] : '../assets/images/course-placeholder.jpg'; ?>" alt="<?php echo $course['title']; ?>" class="course-image">
                            <div class="course-content">
                                <h3 class="course-title"><?php echo $course['title']; ?></h3>
                                <p class="course-description"><?php echo truncateText($course['description'], 100); ?></p>
                                <div class="course-meta">
                                    <span><?php echo $course['grade']; ?></span>
                                    <span><?php echo $course['type'] === 'azhar' ? 'الأزهر' : 'التعليم العام'; ?></span>
                                </div>
                                <a href="course-details.php?id=<?php echo $course['id']; ?>" class="btn btn-primary">عرض التفاصيل</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <div class="view-all">
                <a href="courses.php" class="btn btn-outline">عرض جميع الدورات</a>
            </div>
        </div>
    </section>
    
    <!-- قسم مميزات المنصة -->
    <section class="section features-section">
        <div class="container">
            <h2 class="section-title">لماذا عربي بلس؟</h2>
            
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <img src="../assets/images/icons/teacher.png" alt="مدرسين متميزين" onerror="this.src='../assets/images/icon-placeholder.png'">
                    </div>
                    <h3 class="feature-title">مدرسين متميزين</h3>
                    <p class="feature-description">نخبة من أفضل المدرسين المتخصصين في تدريس اللغة العربية</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <img src="../assets/images/icons/curriculum.png" alt="محتوى تعليمي متكامل" onerror="this.src='../assets/images/icon-placeholder.png'">
                    </div>
                    <h3 class="feature-title">محتوى تعليمي متكامل</h3>
                    <p class="feature-description">شرح مفصل لجميع أجزاء المنهج بطريقة مبسطة وسهلة الفهم</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <img src="../assets/images/icons/anytime.png" alt="تعلم في أي وقت" onerror="this.src='../assets/images/icon-placeholder.png'">
                    </div>
                    <h3 class="feature-title">تعلم في أي وقت</h3>
                    <p class="feature-description">يمكنك الوصول إلى المحتوى التعليمي في أي وقت ومن أي مكان</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <img src="../assets/images/icons/support.png" alt="دعم مستمر" onerror="this.src='../assets/images/icon-placeholder.png'">
                    </div>
                    <h3 class="feature-title">دعم مستمر</h3>
                    <p class="feature-description">فريق دعم متكامل للإجابة على استفساراتك وحل المشكلات التي تواجهك</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- قسم الاشتراكات -->
    <section class="section subscription-section">
        <div class="container">
            <h2 class="section-title">خطط الاشتراك</h2>
            
            <div class="subscription-plans">
                <div class="plan-card">
                    <h3 class="plan-name">الاشتراك الشهري</h3>
                    <div class="plan-price">100 جنيه <span>/ شهر</span></div>
                    <ul class="plan-features">
                        <li>الوصول إلى جميع الدورات</li>
                        <li>مشاهدة غير محدودة للفيديوهات</li>
                        <li>دعم فني عبر البريد الإلكتروني</li>
                    </ul>
                    <a href="subscription.php?plan=monthly" class="btn btn-primary subscribe-btn" data-plan-id="monthly">اشترك الآن</a>
                </div>
                
                <div class="plan-card featured-plan">
                    <h3 class="plan-name">الاشتراك الربع سنوي</h3>
                    <div class="plan-price">250 جنيه <span>/ 3 أشهر</span></div>
                    <ul class="plan-features">
                        <li>الوصول إلى جميع الدورات</li>
                        <li>مشاهدة غير محدودة للفيديوهات</li>
                        <li>دعم فني عبر البريد الإلكتروني</li>
                        <li>توفير 50 جنيه عن الاشتراك الشهري</li>
                    </ul>
                    <a href="subscription.php?plan=quarterly" class="btn btn-primary subscribe-btn" data-plan-id="quarterly">اشترك الآن</a>
                </div>
                
                <div class="plan-card">
                    <h3 class="plan-name">الاشتراك السنوي</h3>
                    <div class="plan-price">900 جنيه <span>/ سنة</span></div>
                    <ul class="plan-features">
                        <li>الوصول إلى جميع الدورات</li>
                        <li>مشاهدة غير محدودة للفيديوهات</li>
                        <li>دعم فني عبر البريد الإلكتروني</li>
                        <li>توفير 300 جنيه عن الاشتراك الشهري</li>
                        <li>أولوية في الدعم الفني</li>
                    </ul>
                    <a href="subscription.php?plan=yearly" class="btn btn-primary subscribe-btn" data-plan-id="yearly">اشترك الآن</a>
                </div>
            </div>
        </div>
    </section>
    
    <!-- التذييل -->
    <footer>
        <div class="container">
            <ul class="footer-links">
                <li><a href="index.php">الرئيسية</a></li>
                <li><a href="courses.php">الدورات</a></li>
                <li><a href="subscription.php">الاشتراكات</a></li>
                <li><a href="about.php">عن المنصة</a></li>
                <li><a href="contact.php">اتصل بنا</a></li>
                <li><a href="privacy.php">سياسة الخصوصية</a></li>
                <li><a href="terms.php">شروط الاستخدام</a></li>
            </ul>
            
            <div class="copyright">
                &copy; <?php echo date('Y'); ?> عربي بلس - جميع الحقوق محفوظة
            </div>
        </div>
    </footer>
    
    <script src="../assets/js/main.js"></script>
</body>
</html>
