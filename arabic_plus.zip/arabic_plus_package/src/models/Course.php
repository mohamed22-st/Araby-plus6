<?php
/**
 * نموذج الدورة
 * يتعامل مع عمليات الدورات مثل إنشاء وتعديل وحذف الدورات
 */
class Course {
    private $db;
    
    /**
     * المُنشئ - يقوم بإنشاء اتصال بقاعدة البيانات
     */
    public function __construct() {
        $this->db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($this->db->connect_error) {
            die("فشل الاتصال بقاعدة البيانات: " . $this->db->connect_error);
        }
    }
    
    /**
     * إنشاء دورة جديدة
     * 
     * @param string $title عنوان الدورة
     * @param string $description وصف الدورة
     * @param string $grade الصف الدراسي
     * @param string $type نوع الدورة (azhar, general)
     * @param string $thumbnail مسار الصورة المصغرة (اختياري)
     * @return bool|int معرف الدورة الجديدة أو false في حالة الفشل
     */
    public function createCourse($title, $description, $grade, $type, $thumbnail = null) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("INSERT INTO courses (title, description, grade, type, thumbnail) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $title, $description, $grade, $type, $thumbnail);
        
        // تنفيذ الاستعلام
        if ($stmt->execute()) {
            $courseId = $stmt->insert_id;
            $stmt->close();
            return $courseId;
        } else {
            $stmt->close();
            return false;
        }
    }
    
    /**
     * تحديث دورة
     * 
     * @param int $id معرف الدورة
     * @param array $data البيانات المراد تحديثها
     * @return bool نجاح أو فشل العملية
     */
    public function updateCourse($id, $data) {
        // بناء استعلام التحديث
        $query = "UPDATE courses SET ";
        $params = [];
        $types = "";
        
        foreach ($data as $key => $value) {
            if ($key !== 'id') {
                $query .= "$key = ?, ";
                $params[] = $value;
                
                // تحديد نوع البيانات
                if (is_int($value)) {
                    $types .= "i";
                } elseif (is_double($value)) {
                    $types .= "d";
                } else {
                    $types .= "s";
                }
            }
        }
        
        // إزالة الفاصلة الأخيرة والمسافة
        $query = rtrim($query, ", ");
        
        // إضافة شرط WHERE
        $query .= " WHERE id = ?";
        $params[] = $id;
        $types .= "i";
        
        // إعداد الاستعلام
        $stmt = $this->db->prepare($query);
        
        // ربط المعلمات
        $stmt->bind_param($types, ...$params);
        
        // تنفيذ الاستعلام
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    }
    
    /**
     * حذف دورة
     * 
     * @param int $id معرف الدورة
     * @return bool نجاح أو فشل العملية
     */
    public function deleteCourse($id) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("DELETE FROM courses WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        // تنفيذ الاستعلام
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    }
    
    /**
     * الحصول على دورة باستخدام المعرف
     * 
     * @param int $id معرف الدورة
     * @return bool|array بيانات الدورة أو false إذا لم يتم العثور عليها
     */
    public function getCourseById($id) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT * FROM courses WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $course = $result->fetch_assoc();
            $stmt->close();
            return $course;
        }
        
        $stmt->close();
        return false;
    }
    
    /**
     * الحصول على جميع الدورات
     * 
     * @param string $type نوع الدورة (اختياري)
     * @param string $grade الصف الدراسي (اختياري)
     * @return array قائمة الدورات
     */
    public function getAllCourses($type = null, $grade = null) {
        // بناء الاستعلام
        $query = "SELECT * FROM courses";
        $conditions = [];
        $params = [];
        $types = "";
        
        if ($type) {
            $conditions[] = "type = ?";
            $params[] = $type;
            $types .= "s";
        }
        
        if ($grade) {
            $conditions[] = "grade = ?";
            $params[] = $grade;
            $types .= "s";
        }
        
        if (!empty($conditions)) {
            $query .= " WHERE " . implode(" AND ", $conditions);
        }
        
        $query .= " ORDER BY created_at DESC";
        
        // إعداد الاستعلام
        $stmt = $this->db->prepare($query);
        
        // ربط المعلمات إذا كانت موجودة
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        $courses = [];
        while ($row = $result->fetch_assoc()) {
            $courses[] = $row;
        }
        
        $stmt->close();
        return $courses;
    }
    
    /**
     * الحصول على الدورات المميزة
     * 
     * @param int $limit عدد الدورات (افتراضيًا: 6)
     * @return array قائمة الدورات المميزة
     */
    public function getFeaturedCourses($limit = 6) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT * FROM courses ORDER BY created_at DESC LIMIT ?");
        $stmt->bind_param("i", $limit);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        $courses = [];
        while ($row = $result->fetch_assoc()) {
            $courses[] = $row;
        }
        
        $stmt->close();
        return $courses;
    }
    
    /**
     * البحث عن دورات
     * 
     * @param string $keyword كلمة البحث
     * @return array نتائج البحث
     */
    public function searchCourses($keyword) {
        // إعداد الاستعلام
        $searchTerm = "%$keyword%";
        $stmt = $this->db->prepare("SELECT * FROM courses WHERE title LIKE ? OR description LIKE ? OR grade LIKE ?");
        $stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        $courses = [];
        while ($row = $result->fetch_assoc()) {
            $courses[] = $row;
        }
        
        $stmt->close();
        return $courses;
    }
    
    /**
     * عدد الدورات
     * 
     * @param string $type نوع الدورة (اختياري)
     * @return int عدد الدورات
     */
    public function countCourses($type = null) {
        // بناء الاستعلام
        $query = "SELECT COUNT(*) as count FROM courses";
        
        if ($type) {
            $query .= " WHERE type = ?";
            $stmt = $this->db->prepare($query);
            $stmt->bind_param("s", $type);
        } else {
            $stmt = $this->db->prepare($query);
        }
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        $stmt->close();
        return $row['count'];
    }
    
    /**
     * الحصول على الدورات حسب الصف الدراسي
     * 
     * @param string $grade الصف الدراسي
     * @return array قائمة الدورات
     */
    public function getCoursesByGrade($grade) {
        // إعداد الاستعلام
        $stmt = $this->db->prepare("SELECT * FROM courses WHERE grade = ? ORDER BY created_at DESC");
        $stmt->bind_param("s", $grade);
        
        // تنفيذ الاستعلام
        $stmt->execute();
        $result = $stmt->get_result();
        
        $courses = [];
        while ($row = $result->fetch_assoc()) {
            $courses[] = $row;
        }
        
        $stmt->close();
        return $courses;
    }
}
?>
