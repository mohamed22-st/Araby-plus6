<?php
// تضمين ملف التكوين
require_once '../src/config/config.php';

// تضمين النماذج المطلوبة
require_once '../src/models/Subscription.php';

// تحديد نوع الخطة المختارة
$selectedPlan = isset($_GET['plan']) ? $_GET['plan'] : 'monthly';

// تعريف خطط الاشتراك
$plans = [
    'monthly' => [
        'name' => 'الاشتراك الشهري',
        'price' => 100,
        'duration' => 'شهر',
        'features' => [
            'الوصول إلى جميع الدورات',
            'مشاهدة غير محدودة للفيديوهات',
            'دعم فني عبر البريد الإلكتروني'
        ]
    ],
    'quarterly' => [
        'name' => 'الاشتراك الربع سنوي',
        'price' => 250,
        'duration' => '3 أشهر',
        'features' => [
            'الوصول إلى جميع الدورات',
            'مشاهدة غير محدودة للفيديوهات',
            'دعم فني عبر البريد الإلكتروني',
            'توفير 50 جنيه عن الاشتراك الشهري'
        ]
    ],
    'yearly' => [
        'name' => 'الاشتراك السنوي',
        'price' => 900,
        'duration' => 'سنة',
        'features' => [
            'الوصول إلى جميع الدورات',
            'مشاهدة غير محدودة للفيديوهات',
            'دعم فني عبر البريد الإلكتروني',
            'توفير 300 جنيه عن الاشتراك الشهري',
            'أولوية في الدعم الفني'
        ]
    ]
];

// التحقق من وجود الخطة المختارة
if (!array_key_exists($selectedPlan, $plans)) {
    $selectedPlan = 'monthly';
}

// الحصول على معلومات الاشتراك النشط للمستخدم الحالي
$activeSubscription = null;
if (isLoggedIn()) {
    $subscriptionModel = new Subscription();
    $activeSubscription = $subscriptionModel->getActiveSubscription($_SESSION['user_id']);
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الاشتراكات - عربي بلس</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Tajawal:wght@400;500;700&display=swap">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- القائمة العلوية -->
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <img src="../assets/images/logo.png" alt="عربي بلس" onerror="this.src='../assets/images/logo-placeholder.png'">
                </a>
                
                <ul class="nav-links">
                    <li><a href="index.php">الرئيسية</a></li>
                    <li><a href="courses.php">الدورات</a></li>
                    <li><a href="subscription.php" class="active">الاشتراكات</a></li>
                    <li><a href="about.php">عن المنصة</a></li>
                    <li><a href="contact.php">اتصل بنا</a></li>
                </ul>
                
                <div class="auth-buttons">
                    <?php if (isLoggedIn()): ?>
                        <a href="dashboard.php" class="btn btn-outline">لوحة التحكم</a>
                        <a href="logout.php" class="btn btn-primary">تسجيل الخروج</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-outline">تسجيل الدخول</a>
                        <a href="register.php" class="btn btn-primary">إنشاء حساب</a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>
    
    <!-- قسم الاشتراكات -->
    <section class="section subscription-section">
        <div class="container">
            <h1 class="section-title">خطط الاشتراك</h1>
            
            <?php displayFlashMessage(); ?>
            
            <?php if ($activeSubscription): ?>
                <div class="active-subscription-info">
                    <h2>اشتراكك الحالي</h2>
                    <div class="subscription-details">
                        <p>
                            <strong>نوع الاشتراك:</strong>
                            <?php
                            switch ($activeSubscription['plan_type']) {
                                case 'monthly':
                                    echo 'شهري';
                                    break;
                                case 'quarterly':
                                    echo 'ربع سنوي';
                                    break;
                                case 'yearly':
                                    echo 'سنوي';
                                    break;
                            }
                            ?>
                        </p>
                        <p><strong>تاريخ البداية:</strong> <?php echo formatArabicDate($activeSubscription['start_date']); ?></p>
                        <p><strong>تاريخ الانتهاء:</strong> <?php echo formatArabicDate($activeSubscription['end_date']); ?></p>
                        <p><strong>الحالة:</strong> نشط</p>
                    </div>
                    <p class="subscription-note">يمكنك تجديد اشتراكك قبل انتهائه للاستمرار في الاستفادة من خدمات المنصة</p>
                </div>
            <?php endif; ?>
            
            <div class="subscription-plans">
                <?php foreach ($plans as $planKey => $plan): ?>
                    <div class="plan-card <?php echo $planKey === $selectedPlan ? 'featured-plan' : ''; ?>">
                        <h3 class="plan-name"><?php echo $plan['name']; ?></h3>
                        <div class="plan-price"><?php echo $plan['price']; ?> جنيه <span>/ <?php echo $plan['duration']; ?></span></div>
                        <ul class="plan-features">
                            <?php foreach ($plan['features'] as $feature): ?>
                                <li><?php echo $feature; ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <?php if (isLoggedIn()): ?>
                            <a href="payment.php?plan=<?php echo $planKey; ?>" class="btn btn-primary subscribe-btn">اشترك الآن</a>
                        <?php else: ?>
                            <a href="login.php?redirect=subscription.php?plan=<?php echo $planKey; ?>" class="btn btn-primary subscribe-btn">تسجيل الدخول للاشتراك</a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="subscription-info">
                <h2>مميزات الاشتراك</h2>
                <ul>
                    <li>الوصول إلى جميع الدورات التعليمية في اللغة العربية للمراحل الإعدادية والثانوية</li>
                    <li>مشاهدة غير محدودة لجميع الفيديوهات التعليمية</li>
                    <li>محتوى تعليمي متجدد باستمرار</li>
                    <li>دعم فني متواصل لحل أي مشكلة</li>
                    <li>إمكانية الوصول من أي جهاز وفي أي وقت</li>
                </ul>
            </div>
            
            <div class="payment-methods">
                <h2>طرق الدفع المتاحة</h2>
                <div class="payment-icons">
                    <div class="payment-icon">
                        <img src="../assets/images/payment/vodafone-cash.png" alt="فودافون كاش" onerror="this.src='../assets/images/payment-placeholder.png'">
                        <span>فودافون كاش</span>
                    </div>
                </div>
            </div>
            
            <div class="faq-section">
                <h2>الأسئلة الشائعة</h2>
                
                <div class="faq-item">
                    <h3>كيف يمكنني الاشتراك في المنصة؟</h3>
                    <p>يمكنك الاشتراك في المنصة من خلال اختيار خطة الاشتراك المناسبة لك، ثم اتباع خطوات الدفع عبر فودافون كاش.</p>
                </div>
                
                <div class="faq-item">
                    <h3>هل يمكنني إلغاء اشتراكي في أي وقت؟</h3>
                    <p>نعم، يمكنك إلغاء اشتراكك في أي وقت، ولكن لن يتم استرداد المبلغ المدفوع عن الفترة المتبقية من الاشتراك.</p>
                </div>
                
                <div class="faq-item">
                    <h3>هل يتجدد الاشتراك تلقائيًا؟</h3>
                    <p>لا، لا يتجدد الاشتراك تلقائيًا. يجب عليك تجديد اشتراكك يدويًا قبل انتهاء فترة الاشتراك الحالية.</p>
                </div>
                
                <div class="faq-item">
                    <h3>ماذا يحدث عند انتهاء فترة اشتراكي؟</h3>
                    <p>عند انتهاء فترة اشتراكك، لن تتمكن من الوصول إلى محتوى الدورات والفيديوهات حتى تقوم بتجديد الاشتراك.</p>
                </div>
                
                <div class="faq-item">
                    <h3>هل يمكنني تغيير خطة الاشتراك؟</h3>
                    <p>نعم، يمكنك تغيير خطة الاشتراك عند تجديد اشتراكك.</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- التذييل -->
    <footer>
        <div class="container">
            <ul class="footer-links">
                <li><a href="index.php">الرئيسية</a></li>
                <li><a href="courses.php">الدورات</a></li>
                <li><a href="subscription.php">الاشتراكات</a></li>
                <li><a href="about.php">عن المنصة</a></li>
                <li><a href="contact.php">اتصل بنا</a></li>
                <li><a href="privacy.php">سياسة الخصوصية</a></li>
                <li><a href="terms.php">شروط الاستخدام</a></li>
            </ul>
            
            <div class="copyright">
                &copy; <?php echo date('Y'); ?> عربي بلس - جميع الحقوق محفوظة
            </div>
        </div>
    </footer>
    
    <script src="../assets/js/main.js"></script>
</body>
</html>
